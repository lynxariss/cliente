### **Whimscape x Fresh Animations 1.20-1.21.11_r3** (2026 Mar 23)

- Added horse armor textures again
- Fixed warm chicken and warm pig (FA 1.10.4)
- Fixed pig saddle texture for game versions before 1.21.5

________________________________________________________________

### **Whimscape x Fresh Animations 1.20-1.21.11_r2** (2026 Jan 14)

- Fixed cows being mostly invisible when using Forge 1.20.1 and Oculus

________________________________________________________________

### **Whimscape x Fresh Animations 1.20-1.21.11_r1** (2025 Dec 19)

- Changed horse saddle textures
- Removed horse armor textures

________________________________________________________________

### **Whimscape x Fresh Animations 1.20-1.21.10_r1** (2025 Nov 26)

- Fixed mooshroom blinks (FA 1.10.2)
- Fixed rule_index handling for bee, chickens, cows, mooshroom, pigs (FA 1.10.2)

________________________________________________________________

### **Whimscape x Fresh Animations 1.20-1.21.8_r1** (2025 Oct 28)

> **NOTE**: Use EMF for game versions 1.20-1.21.2. OptiFine will not work.

- Allay
    - Changed texture to the one in Whimscape 1.20.2-1.21.10_r1
- Axolotl
    - Fixed texture: eye position
- Bat
    - Added texture
- Bee
    - Added bee.properties
    - Changed bee_baby.properties
    - Changed models to depend on FA for animations
- Bogged
    - Added model
    - Fixed texture
    - Removed model parts
- Cave spider
    - Added model
    - Fixed texture
    - Removed model parts and their texture
- Chicken
    - Added models
    - Added chicken.properties & chicken_baby.properties
    - Removed model parts
- Cold chicken
    - Added model
- Cold cow
    - Changed model to depend on FA for animations (baked in some animations from FA:Details)
    - Changed texture: added separate tail
- Cold pig
    - Added cold_pig_baby model
    - Added cold_pig_baby.properties
    - Changed model to depend on FA for animations (baked in some animations from FA:Details)
    - Changed texture: separated eyes from face
- Cow
    - Added cow.properties & cow_baby.properties
    - Changed models to depend on FA for animations (baked in some animations from FA:Details)
    - Changed texture: added separate tail
- Creeper
    - Added model
    - Fixed texture
    - Removed model parts
- Dolphin
    - Added model from FA 1.10.1 and corrected right fin texture mirroring
- Donkey
    - Fixed texture: flipped saddlebags
- Drowned
    - Added textures
- Elder guardian
    - Added texture
- Enderman
    - Changed texture: tweaked jaw
- Endermite
    - Added textures
- Evoker
    - Added model
    - Changed texture: separated eyes from face, lengthened eyebrows
    - Removed model parts
- Glow squid
    - Added texture
- Goat
    - Removed goat_baby.properties
- Guardian
    - Added model from FA 1.10.1 with an added eye glint
    - Added texture
- Happy ghast
    - Added texture
- Hoglin
    - Added model
    - Fixed textures
    - Removed model part and its texture
- Horse
    - Added armor textures
- Husk
    - Added texture
- Illusioner
    - Added model
    - Changed texture: separated eyes from face
    - Removed model part
- Magma cube
    - Fixed texture
- Mooshroom
    - Changed models to depend on FA for animations
    - Changed textures: added separate tail
    - Changed mooshroom.properties & mooshroom_baby.properties
- Mule
    - Fixed texture: flipped saddlebags
- Parrot
    - Fixed textures: eyes
- Pig
    - Added pig.properties
    - Fixed pig_saddle texture dimensions
    - Changed model to depend on FA for animations (baked in some animations from FA:Details)
    - Changed texture: separated eyes from face
    - Changed pig_baby.properties
- Piglins
    - Changed textures: separated eyes from faces
- Pillager
    - Added model
    - Changed texture: separated eyes from face, lengthened eyebrows
    - Removed model parts
- Sheep
    - Added models
    - Fixed texture
    - Removed model parts
- Snow golem
    - Added texture
- Spider
    - Added model
    - Fixed texture
    - Removed model parts and their texture
- Squid
    - Added texture
- Strider
    - Fixed texture: hair position
- Villager
    - Added models
    - Added villager.properties & villager_baby.properties
    - Changed texture: separated eyes from face
    - Removed model parts
- Vindicator
    - Added model
    - Changed texture: separated eyes from face, lengthened eyebrows
    - Removed model parts
- Wandering trader
    - Added model
    - Fixed texture
    - Removed model parts
- Warm cow
    - Added model
    - Changed texture: added separate tail and tweaked horns
- Warm pig
    - Changed texture: separated eyes from face
- Witch
    - Added model
    - Changed texture: separated eyes and mouth from face, tweaked collar of robe
    - Removed model parts
- Wolf
    - Added model
    - Changed textures: separated eyes from faces
    - Removed model part
- Zoglin
    - Added model
    - Fixed texture
    - Removed model part and its texture
- Zombie
    - Added texture
- Zombie villager
    - Added model
    - Removed model parts
- Removed overlay folders

________________________________________________________________

### **Whimscape x Fresh Animations 1.20.2-1.21.5_r1** (2025 May 18)

- Fixed chickens, cows and pigs and their variants for 1.21.5 (FA 1.9.4+)
- Fixed babies of cows, goats, mooshrooms and pigs reverting to default models under certain conditions with OptiFine (FA 1.9.3+)
- Fixed bee babies not using the Whimscape model (FA 1.9.3+)
- Fixed saddles
- Fixed sheep leg mirroring
- Changed cow texture slightly

________________________________________________________________

### **Whimscape x Fresh Animations 1.20.2-1.21.4_r2** (2025 Apr 20)

- Added pig model matching the new one in Whimscape 1.20.2-1.21.5_r2
- Changed pig texture for the new model
- Changed chicken textures

________________________________________________________________

### **Whimscape x Fresh Animations 1.20.2-1.21.4_r1** (2024 Dec 19)

- Fixed mooshroom baby for 1.21.2 / FA 1.9.3

________________________________________________________________

### **Whimscape x Fresh Animations 1.20.2-1.21.3_r1** (2024 Oct 28)

- Fixed mooshrooms

________________________________________________________________

### **Whimscape x Fresh Animations 1.20.2-1.21_r1** (2024 Jul 10)

- Added bogged with custom mushroom parts
- Fixed wolves
- Fixed colored shulkers
- Changed vindicator pants color

________________________________________________________________

### **Whimscape x Fresh Animations 1.20.2-1.20.4_r1** (2024 Mar 14)

- Changed pack_format to 18, added supported_formats to pack.mcmeta

________________________________________________________________

### **Whimscape x Fresh Animations 1.20-1.20.1_r1** (2024 Mar 14)

- Fixed allay, bee, creeper, goat, shulker and sniffer for FA 1.9
- Fixed z-fighting in hoglin and zoglin manes
- Changed pack_format to 15

________________________________________________________________

### **Whimscape x Fresh Animations 1.19.4_r1** (2024 Mar 14)

- Fixed allay, bee, creeper, goat and shulker for FA 1.9
- Fixed z-fighting in hoglin and zoglin manes
- Changed pack_format to 13

________________________________________________________________

### **Whimscape x Fresh Animations 1.19.3_r1** (2023 Jun 09)

- Fixed vex textures for the new model
- Changed horse_creamy colors slightly
- Changed pack_format to 12

________________________________________________________________

### **Whimscape x Fresh Animations 1.19_r1** (2023 Feb 10)
- Initial release