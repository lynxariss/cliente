#version 330 compatibility
/* RENDERTARGETS: 0,1 */

// End dimension: discard vanilla sky geometry
// End sky is rendered in the composite pass
void main() {
    discard;
}
