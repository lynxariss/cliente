
#include "/settings.glsl"
#include "/include/waving.glsl"
#include "/include/shadow.glsl"
#include "/include/hovering.glsl"

out vec2 texcoord;
flat out int block_id_out;

uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowModelViewInverse;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;

attribute vec4 mc_Entity;
attribute vec4 mc_midTexCoord;
attribute vec4 at_midBlock;

vec3 transform(mat4 m, vec3 p) {
	return (m * vec4(p, 1.0)).xyz;
}

void main() {
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

	float skylight = clamp(gl_MultiTexCoord1.y / 240.0, 0.0, 1.0);
	bool is_top_vertex = texcoord.y < mc_midTexCoord.y;

	int block_id_raw = int(mc_Entity.x);
	bool has_block_properties_id = (block_id_raw >= 10000);
	int block_id = has_block_properties_id ? (block_id_raw - 10000) : 0;
	block_id_out = block_id;

	bool should_wave = false;
	#ifdef WAVING_PLANTS
	should_wave = should_wave || (block_id == 2 || block_id == 3 || block_id == 4);
	#ifdef GRASS_3D_RP_MODE
	should_wave = should_wave || (block_id == 15);
	#endif
	#endif
	#ifdef WAVING_LEAVES
	should_wave = should_wave || (block_id == 5);
	#endif
	#ifdef SWAYING_LANTERNS
	should_wave = should_wave || (block_id == 6);
	#endif

	should_wave = should_wave && has_block_properties_id;

	vec3 pos = transform(gl_ModelViewMatrix, gl_Vertex.xyz);
	vec3 world_pos = transform(shadowModelViewInverse, pos) + cameraPosition;

	if (should_wave) {
		world_pos = animate_vertex(world_pos, is_top_vertex, skylight, block_id, at_midBlock.xyz);
	}

	// Apply hover offset (must match gbuffers_terrain.vsh)
	float hoverOffset = getHoverOffset(world_pos);
	world_pos.y += hoverOffset;

	pos = transform(shadowModelView, world_pos - cameraPosition);

	gl_Position = gl_ProjectionMatrix * vec4(pos, 1.0);

	// Apply distortion - MUST match sampling exactly (per shaders.properties guide)
	gl_Position.xyz = distortShadowClipPos(gl_Position.xyz);
}
