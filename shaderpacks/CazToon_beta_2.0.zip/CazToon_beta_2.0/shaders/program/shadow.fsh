
#include "/settings.glsl"

uniform sampler2D gtexture;
uniform float alphaTestRef;

in vec2 texcoord;
flat in int block_id_out;

/* DRAWBUFFERS:0 */
layout(location = 0) out vec4 shadowcolor;

void main() {
	// ID 2 = grass, short_grass, fern, crops, small flowers, saplings
	// ID 3 = lower half of tall plants (tall_grass, large_fern, etc)
	// ID 4 = upper half of tall plants
	// ID 19 = azalea, flowering_azalea (bush blocks)
	// ID 15 = grass_block: in 3D RP mode the blade decoration casts shadow artifacts
	#ifdef GRASS_3D_RP_MODE
	if (block_id_out == 2 || block_id_out == 3 || block_id_out == 4 || block_id_out == 15 || block_id_out == 19) {
		discard;
	}
	#else
	if (block_id_out == 2 || block_id_out == 3 || block_id_out == 4 || block_id_out == 19) {
		discard;
	}
	#endif

	vec4 color = texture(gtexture, texcoord);

	if (color.a < 0.01) {
		discard;
	}

	shadowcolor = color;
}
