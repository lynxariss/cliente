// End Sky rendering - included from composite pass
// Requires: settings.glsl already included
// Requires uniforms: frameTimeCounter, gbufferProjectionInverse, gbufferModelViewInverse

#ifdef END_SKY_ENABLED

#ifdef END_EVENT_ENABLED
#include "/include/end_event.glsl"
#endif

// === Noise utilities ===

float endHash21(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

vec2 endHash22(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.xx + p3.yz) * p3.zy);
}

// 3D hash — no projection needed, no seams
float endHash31(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.zyx + 31.32);
    return fract((p.x + p.y) * p.z);
}

// 3D value noise — operates directly on world direction, seamless on sphere
float endNoise3D(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);

    float a = endHash31(i);
    float b = endHash31(i + vec3(1,0,0));
    float c = endHash31(i + vec3(0,1,0));
    float d = endHash31(i + vec3(1,1,0));
    float e = endHash31(i + vec3(0,0,1));
    float g = endHash31(i + vec3(1,0,1));
    float h = endHash31(i + vec3(0,1,1));
    float k = endHash31(i + vec3(1,1,1));

    return mix(mix(mix(a, b, f.x), mix(c, d, f.x), f.y),
               mix(mix(e, g, f.x), mix(h, k, f.x), f.y), f.z);
}

// 3D FBM — seamless on any surface
float endFbm3D(vec3 p, int octaves) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    for (int i = 0; i < octaves; i++) {
        value += amplitude * endNoise3D(p * frequency);
        frequency *= 2.0;
        amplitude *= 0.5;
    }
    return value;
}

// 3D Voronoi
float endVoronoi3D(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    float minDist = 1.0;
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            for (int z = -1; z <= 1; z++) {
                vec3 neighbor = vec3(float(x), float(y), float(z));
                vec3 point = vec3(endHash31(i + neighbor + vec3(0.0)),
                                  endHash31(i + neighbor + vec3(100.0)),
                                  endHash31(i + neighbor + vec3(200.0)));
                float dist = length(neighbor + point - f);
                minDist = min(minDist, dist);
            }
        }
    }
    return minDist;
}

// Cube projection for stars/particles (point features — seams don't matter)
vec2 endCubeProject(vec3 d) {
    vec3 a = abs(d);
    if (a.x >= a.y && a.x >= a.z) return d.yz / a.x + vec2(0.0, 2.0) * sign(d.x);
    else if (a.y >= a.z) return d.xz / a.y + vec2(4.0, 0.0) * sign(d.y);
    else return d.xy / a.z + vec2(0.0, 6.0) * sign(d.z);
}

vec3 endBlendSkyLayers(vec3 horizon, vec3 mid, vec3 zenith, float height, float midH, float zenithH) {
    float toMid = clamp((height - 0.0) / midH, 0.0, 1.0);
    toMid = toMid * toMid * toMid * (toMid * (toMid * 6.0 - 15.0) + 10.0);
    float toZenith = clamp((height - midH) / (zenithH - midH), 0.0, 1.0);
    toZenith = toZenith * toZenith * toZenith * (toZenith * (toZenith * 6.0 - 15.0) + 10.0);
    vec3 result = mix(horizon, mid, toMid);
    result = mix(result, zenith, toZenith);
    return result;
}

// === End Sky Effects ===

#ifdef END_STARS_ENABLED
vec3 endStarField(vec3 dir, float time, float suctionWarp) {
    dir = normalize(dir);
    // During event: black-hole suction — warp sample dir AWAY from zenith
    // so stars visually stream upward into the vortex
    if (suctionWarp > 0.001) {
        float warpStrength = suctionWarp * suctionWarp * 0.85;
        vec3 horizDir = normalize(vec3(dir.x, 0.0, dir.z));
        float nearZenith = clamp(dir.y, 0.0, 1.0);
        float pullAmount = warpStrength * nearZenith;
        dir = normalize(mix(dir, horizDir, pullAmount));
    }
    vec2 starUV = endCubeProject(dir) * STAR_SCALE;
    vec2 cell = floor(starUV);
    vec2 local = fract(starUV);
    vec3 result = vec3(0.0);

    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            vec2 nc = cell + vec2(float(x), float(y));
            float rnd = endHash21(nc);
            if (rnd > END_STAR_DENSITY) continue;

            vec2 sp = endHash22(nc) * 0.6 + 0.2;
            vec2 d = local - vec2(float(x), float(y)) - sp;
            float dist = length(d);
            float baseBright = 0.4 + endHash21(nc + 500.0) * 0.6;
            float twinklePhase = endHash21(nc + 700.0) * 6.28318;
            float twinkleSpeed = 0.5 + endHash21(nc + 800.0) * 2.0;
            float twinkle = 0.7 + 0.3 * sin(time * twinkleSpeed + twinklePhase);
            float bright = baseBright * twinkle * END_STAR_BRIGHTNESS;
            float radius = STAR_SIZE * (0.5 + endHash21(nc + 400.0) * 0.5);
            float s = 1.0 - smoothstep(0.0, radius, dist);

            vec3 sColor = vec3(1.0);
            if (END_STAR_COLOR_SHIFT > 0.0) {
                float colorRnd = endHash21(nc + 1000.0);
                vec3 tint;
                if (colorRnd < 0.3) tint = vec3(0.7, 0.5, 1.0);
                else if (colorRnd < 0.55) tint = vec3(0.4, 0.7, 1.0);
                else if (colorRnd < 0.75) tint = vec3(0.3, 0.9, 0.8);
                else tint = vec3(1.0, 0.95, 0.9);
                sColor = mix(vec3(1.0), tint, END_STAR_COLOR_SHIFT);
            }
            result = max(result, sColor * s * bright);
        }
    }
    return result;
}
#endif

#ifdef END_NEBULA_ENABLED
vec3 endNebula(vec3 dir, float time) {
    // Use 3D noise on the direction vector — completely seamless, no projection
    vec3 p = normalize(dir) * END_NEBULA_SCALE;
    float drift = time * END_NEBULA_SPEED;
    vec3 p1 = p + vec3(drift, drift * 0.3, drift * 0.1);
    vec3 p2 = p + vec3(-drift * 0.7, drift * 0.5, -drift * 0.2);

    float largeClouds = endFbm3D(p1 * 0.6, 5);
    float largeClouds2 = endFbm3D(p2 * 0.8 + vec3(50.0, 25.0, 10.0), 4);
    float medDetail = endFbm3D(p1 * 1.2 + vec3(100.0, 50.0, 30.0), 4);
    float colorLayer = endFbm3D(p * 0.4 + vec3(-30.0, 80.0, 40.0) + drift * 0.3, 3);
    float v = endVoronoi3D(p1 * 2.0);

    float nebulaMask = smoothstep(0.20, 0.55, largeClouds);
    nebulaMask *= 0.5 + 0.5 * smoothstep(0.15, 0.50, largeClouds2);
    nebulaMask *= 0.6 + 0.4 * smoothstep(0.25, 0.60, medDetail);
    nebulaMask *= 0.6 + 0.4 * (1.0 - smoothstep(0.0, 0.5, v));
    float coreGlow = smoothstep(0.50, 0.80, largeClouds) * 0.5;
    nebulaMask += coreGlow;

    vec3 color1 = vec3(END_NEBULA_R1, END_NEBULA_G1, END_NEBULA_B1);
    vec3 color2 = vec3(END_NEBULA_R2, END_NEBULA_G2, END_NEBULA_B2);
    float colorMix = smoothstep(0.3, 0.7, colorLayer);
    vec3 nebulaColor = mix(color1, color2, colorMix);
    vec3 highlight = vec3(0.7, 0.6, 0.9) * smoothstep(0.70, 0.95, largeClouds) * 0.3;

    return (nebulaColor * nebulaMask + highlight) * END_NEBULA_INTENSITY;
}
#endif

#ifdef END_AURORA_ENABLED
vec3 endAurora(vec3 dir, float time) {
    float elevation = dir.y;
    if (elevation < 0.02) return vec3(0.0);

    float heightMask = smoothstep(0.02, END_AURORA_HEIGHT * 0.3, elevation)
                     * smoothstep(END_AURORA_HEIGHT + 0.3, END_AURORA_HEIGHT * 0.5, elevation);
    float angle = atan(dir.z, dir.x);

    float curtain1 = sin(angle * 3.0 + time * END_AURORA_SPEED * 0.7) * 0.5 + 0.5;
    float curtain2 = sin(angle * 5.0 - time * END_AURORA_SPEED * 1.1 + 2.0) * 0.5 + 0.5;
    float curtain3 = sin(angle * 7.0 + time * END_AURORA_SPEED * 0.4 + 4.5) * 0.5 + 0.5;
    float curtain4 = sin(angle * 2.0 + time * END_AURORA_SPEED * 0.9 + 1.0) * 0.5 + 0.5;

    // Use 3D noise for wave modulation — seamless
    float waveNoise = endNoise3D(vec3(dir.xz * 2.0, time * END_AURORA_SPEED * 0.3));
    float wave = sin(elevation * 12.0 + waveNoise * 4.0 + time * END_AURORA_SPEED) * 0.5 + 0.5;
    float vertStreak = endNoise3D(vec3(dir.xz * 4.0 + time * 0.05, elevation * 8.0));
    vertStreak = smoothstep(0.1, 0.6, vertStreak);

    float auroraShape = curtain1 * curtain2 * 0.5 + curtain3 * 0.3 + curtain4 * 0.2;
    auroraShape *= wave;
    auroraShape *= 0.6 + 0.4 * vertStreak;
    auroraShape = pow(auroraShape, 1.5);

    vec3 color1 = vec3(END_AURORA_R1, END_AURORA_G1, END_AURORA_B1);
    vec3 color2 = vec3(END_AURORA_R2, END_AURORA_G2, END_AURORA_B2);
    float colorPhase = sin(angle * 2.0 + time * END_AURORA_SPEED * 0.2) * 0.5 + 0.5;
    vec3 auroraColor = mix(color1, color2, colorPhase);

    return auroraColor * auroraShape * heightMask * END_AURORA_INTENSITY;
}
#endif

#ifdef END_VOID_PARTICLES_ENABLED
vec3 endVoidParticles(vec3 dir, float time, float suctionWarp) {
    dir = normalize(dir);
    // Black-hole suction — warp sample dir away from zenith
    // so particles visually stream upward into the vortex
    if (suctionWarp > 0.001) {
        float warpStrength = suctionWarp * suctionWarp * 0.85;
        vec3 horizDir = normalize(vec3(dir.x, 0.0, dir.z));
        float nearZenith = clamp(dir.y, 0.0, 1.0);
        float pullAmount = warpStrength * nearZenith;
        dir = normalize(mix(dir, horizDir, pullAmount));
    }
    vec2 particleUV = endCubeProject(dir) * 30.0;
    vec2 cell = floor(particleUV);
    vec2 local = fract(particleUV);
    vec3 result = vec3(0.0);

    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            vec2 nc = cell + vec2(float(x), float(y));
            float rnd = endHash21(nc + vec2(200.0, 300.0));
            if (rnd > END_VOID_PARTICLE_DENSITY) continue;

            vec2 sp = endHash22(nc + vec2(200.0, 300.0)) * 0.6 + 0.2;
            float pulsePhase = endHash21(nc + vec2(500.0, 600.0)) * 6.28318;
            float pulseSpeed = 0.3 + endHash21(nc + vec2(700.0, 800.0)) * 1.5;
            float pulse = 0.5 + 0.5 * sin(time * pulseSpeed + pulsePhase);
            float driftX = sin(time * 0.1 + pulsePhase) * 0.02;
            float driftY = cos(time * 0.08 + pulsePhase * 1.3) * 0.02;

            vec2 d = local - vec2(float(x), float(y)) - sp + vec2(driftX, driftY);
            float dist = length(d);
            float particle = 1.0 - smoothstep(0.0, 0.04, dist);
            particle *= pulse;

            float hueRnd = endHash21(nc + vec2(900.0, 100.0));
            vec3 pColor = mix(vec3(0.6, 0.2, 1.0), vec3(0.2, 0.8, 0.9), hueRnd);
            result += pColor * particle * END_VOID_PARTICLE_BRIGHTNESS * 0.3;
        }
    }
    return result;
}
#endif

#ifdef END_ASTEROIDS_ENABLED
// Fast-flying asteroid streaks — rare, brief flashes that zip across the sky
// Each asteroid has a short lifecycle: appear, streak across, vanish
vec3 endWarpStreaks(vec3 dir, float time) {
    dir = normalize(dir);
    vec3 result = vec3(0.0);

    // Small number of asteroid "slots" — only a few active at any time
    // Each slot cycles through long dormant periods with brief active flashes
    int numSlots = 12;
    for (int slot = 0; slot < numSlots; slot++) {
        float slotF = float(slot);

        // Each slot has a long cycle (mostly dormant) with a brief active window
        float cycleDuration = 8.0 + endHash21(vec2(slotF, 0.0) + vec2(7000.0)) * 12.0; // 8-20 sec per cycle
        float activeWindow = 0.6 + endHash21(vec2(slotF, 1.0) + vec2(7100.0)) * 0.8;   // 0.6-1.4 sec visible
        float phase = endHash21(vec2(slotF, 2.0) + vec2(7200.0)) * 200.0;

        float cycleTime = mod(time * END_ASTEROID_SPEED + phase, cycleDuration);

        // Only visible during the brief active window at the start of each cycle
        if (cycleTime > activeWindow) continue;

        float lifecycle = cycleTime / activeWindow; // 0 to 1 over the visible duration

        // Quick fade in, quick fade out
        float fadeMask = smoothstep(0.0, 0.1, lifecycle) * smoothstep(1.0, 0.85, lifecycle);
        if (fadeMask < 0.001) continue;

        // Random 3D direction for this streak on the sky sphere
        float theta = endHash21(vec2(slotF, 3.0) + vec2(7300.0)) * 6.28318; // azimuth
        float phi = endHash21(vec2(slotF, 4.0) + vec2(7400.0)) * 2.8 - 0.4; // elevation (-0.4 to 2.4 covers most sky)
        vec3 streakCenter = normalize(vec3(cos(theta) * cos(phi), sin(phi), sin(theta) * cos(phi)));

        // Streak travel direction (each one flies in a random direction)
        float travelAngle = endHash21(vec2(slotF, 5.0) + vec2(7500.0)) * 6.28318;
        float travelElev = (endHash21(vec2(slotF, 6.0) + vec2(7600.0)) - 0.5) * 1.0;
        vec3 travelDir = normalize(vec3(cos(travelAngle), travelElev, sin(travelAngle)));

        // Animate: streak moves along travelDir over its life
        float speed = 0.3 + endHash21(vec2(slotF, 7.0) + vec2(7700.0)) * 0.4;
        vec3 currentPos = streakCenter + travelDir * (lifecycle - 0.5) * speed;

        // How close is the current pixel to the streak?
        float dotToStreak = dot(dir, normalize(currentPos));
        float angDist = acos(clamp(dotToStreak, -1.0, 1.0));

        // Skip if too far from the streak position
        if (angDist > END_ASTEROID_LENGTH * 1.5) continue;

        // Project onto the streak line to get along/perpendicular distances
        // Streak direction on the sky sphere
        vec3 streakDir = normalize(travelDir - dir * dot(travelDir, dir));
        float along = dot(dir - normalize(currentPos), streakDir);
        float perp = length(dir - normalize(currentPos) - streakDir * along);

        // Streak shape
        float halfLen = END_ASTEROID_LENGTH * (0.4 + endHash21(vec2(slotF, 8.0) + vec2(7800.0)) * 0.6);
        float thickness = END_ASTEROID_THICKNESS;

        float alongMask = smoothstep(halfLen, halfLen * 0.3, abs(along));
        float perpMask = smoothstep(thickness, thickness * 0.15, perp);
        float streak = alongMask * perpMask;

        // Taper: bright head, fading tail
        float taper = smoothstep(-halfLen, halfLen * 0.2, along);
        streak *= taper * fadeMask;

        // Color
        float colorRnd = endHash21(vec2(slotF, 9.0) + vec2(7900.0));
        vec3 streakColor;
        if (colorRnd < 0.3) streakColor = vec3(0.6, 0.3, 1.0);       // vivid purple
        else if (colorRnd < 0.55) streakColor = vec3(0.3, 0.7, 1.0);  // cyan-blue
        else if (colorRnd < 0.8) streakColor = vec3(0.8, 0.75, 1.0);  // pale lavender
        else streakColor = vec3(1.0, 0.95, 1.0);                      // bright white

        result += streakColor * streak * END_ASTEROID_BRIGHTNESS;
    }

    return result;
}
#endif

#ifdef END_VOID_CLOUDS_ENABLED

// Smooth 3D noise for void clouds — uses quintic interpolation for zero-artifact output
float voidCloudNoise3D(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    // Quintic Hermite interpolation — C2 continuous, eliminates grid artifacts
    f = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);

    float a = endHash31(i);
    float b = endHash31(i + vec3(1,0,0));
    float c = endHash31(i + vec3(0,1,0));
    float d = endHash31(i + vec3(1,1,0));
    float e = endHash31(i + vec3(0,0,1));
    float g = endHash31(i + vec3(1,0,1));
    float h = endHash31(i + vec3(0,1,1));
    float k = endHash31(i + vec3(1,1,1));

    return mix(mix(mix(a, b, f.x), mix(c, d, f.x), f.y),
               mix(mix(e, g, f.x), mix(h, k, f.x), f.y), f.z);
}

// Smooth FBM with fewer octaves at large scale for clean cloud shapes
float voidCloudFBM(vec3 p) {
    float value = 0.0;
    float amp = 0.6;
    float freq = 1.0;
    // 3 octaves — enough shape detail without adding high-frequency noise
    for (int i = 0; i < 3; i++) {
        value += amp * voidCloudNoise3D(p * freq);
        freq *= 2.0;
        amp *= 0.4; // steeper falloff = smoother result
    }
    return value;
}

// Cloud density at a world-space position
// cloudTime = integrated cloud animation time (handles acceleration smoothly)
// rawTime = real elapsed time (for noise drift only)
float voidCloudDensity(vec3 worldPos, float cloudTime, float rawTime, float suctionWarp) {
    float y = worldPos.y;
    // Height bands: above island (y=60..300) and below (y=0..-200)
    float upperBand = smoothstep(60.0, 150.0, y) * smoothstep(400.0, 250.0, y);
    float lowerBand = smoothstep(0.0, -60.0, y) * smoothstep(-300.0, -180.0, y);
    float heightDensity = max(upperBand, lowerBand);

    // Clearing near the island center
    float horizDist = length(worldPos.xz);
    float clearingMask = smoothstep(END_VOID_CLOUD_CLEARING * 80.0,
                                    END_VOID_CLOUD_CLEARING * 300.0, horizDist);

    if (heightDensity < 0.01 || clearingMask < 0.01) return 0.0;

    // Global rotation — entire cloud layer slowly orbits around the island center
    // Uses integrated cloudTime for smooth acceleration without snaps
    float orbitAngle = cloudTime * END_VOID_CLOUD_SWIRL_SPEED * 0.5;
    float cosO = cos(orbitAngle);
    float sinO = sin(orbitAngle);
    vec3 orbitPos = vec3(
        worldPos.x * cosO - worldPos.z * sinO,
        worldPos.y,
        worldPos.x * sinO + worldPos.z * cosO
    );

    // Swirl distortion — additional local twist that varies with height/distance
    float swirlInput = (y * 0.003 + log(max(horizDist, 1.0)) * 0.4) * END_VOID_CLOUD_SWIRL
                      + cloudTime * END_VOID_CLOUD_SWIRL_SPEED;
    float cosA = cos(swirlInput);
    float sinA = sin(swirlInput);
    vec3 swirlPos = vec3(
        orbitPos.x * cosA - orbitPos.z * sinA,
        orbitPos.y,
        orbitPos.x * sinA + orbitPos.z * cosA
    );

    // Very low frequency noise — large smooth cloud formations (uses raw time for drift)
    vec3 noisePos = swirlPos * END_VOID_CLOUD_SCALE * 0.0006
                  + vec3(rawTime * END_VOID_CLOUD_SPEED, rawTime * END_VOID_CLOUD_SPEED * 0.3, 0.0);

    float n = voidCloudFBM(noisePos);

    // Shape into cloud density with wider transition for smoother edges
    float density = smoothstep(END_VOID_CLOUD_COVERAGE, END_VOID_CLOUD_COVERAGE + 0.35, n);
    density *= heightDensity;
    density *= clearingMask;
    // During event: clouds get sucked away, density fades
    density *= (1.0 - suctionWarp * 0.9);

    return density;
}

// Lightning flash — returns a brightness multiplier for cloud illumination
float voidCloudLightning(vec3 worldPos, float time) {
    float flash = 0.0;

    // Multiple independent lightning "cells" across the cloud volume
    // Each cell triggers at random intervals with brief bright flashes
    for (int i = 0; i < 4; i++) {
        float fi = float(i);

        // Random spatial anchor for this lightning cell
        vec3 cellCenter = vec3(
            sin(fi * 73.17) * 400.0,
            cos(fi * 47.53) * 150.0 + 100.0,
            sin(fi * 91.31 + 2.0) * 400.0
        );

        // Distance from this sample to the cell center — lightning illuminates nearby clouds
        float cellDist = length(worldPos - cellCenter);
        float influence = smoothstep(500.0, 50.0, cellDist);
        if (influence < 0.01) continue;

        // Random timing: long dormant periods with brief double-flashes
        float cyclePeriod = 6.0 + fi * 3.5; // 6-16.5 sec cycle per cell
        float phase = fi * 17.3 + 5.0;
        float cycleTime = mod(time + phase, cyclePeriod);

        // Two quick pulses (main flash + afterflash) within a short active window
        float pulse1 = smoothstep(0.0, 0.03, cycleTime) * smoothstep(0.12, 0.05, cycleTime); // ~0.1s flash
        float pulse2 = smoothstep(0.18, 0.21, cycleTime) * smoothstep(0.30, 0.24, cycleTime); // weaker afterflash
        float lightning = pulse1 + pulse2 * 0.5;

        flash += lightning * influence;
    }

    return flash;
}

// Cloud color/lighting at a sample point
vec3 voidCloudLighting(vec3 worldPos, vec3 viewDir, float density, float dist, float time) {
    vec3 color1 = vec3(END_VOID_CLOUD_R1, END_VOID_CLOUD_G1, END_VOID_CLOUD_B1);
    vec3 color2 = vec3(END_VOID_CLOUD_R2, END_VOID_CLOUD_G2, END_VOID_CLOUD_B2);

    // Very smooth color variation
    float colorVar = voidCloudNoise3D(worldPos * 0.0004 + time * 0.003);
    vec3 baseColor = mix(color1, color2, smoothstep(0.3, 0.7, colorVar));

    // Edge glow — thin cloud edges stay bright, not dark
    float edgeBright = (1.0 - density) * END_VOID_CLOUD_EDGE_GLOW;

    // Height-based lighting
    float heightGlow = smoothstep(0.0, 300.0, worldPos.y) * 0.15;
    float belowGlow = max(-viewDir.y, 0.0) * 0.15;

    vec3 cloudColor = baseColor * (END_VOID_CLOUD_INTENSITY + edgeBright + heightGlow + belowGlow);

    // Vortex glow color (#703FF3) — thin edges glow this color like vortex rays extending down
    vec3 vortexGlow = vec3(0.44, 0.25, 0.95);
    float edgeFade = 1.0 - smoothstep(0.0, 0.5, density); // 1 at thin edges, 0 at dense core
    cloudColor = mix(cloudColor, vortexGlow * 0.6, edgeFade * 0.7);

    // Lightning flashes — brief random illumination in dense cloud regions
    float lightning = voidCloudLightning(worldPos, time);
    // Lightning brightens dense cloud interiors with a white-purple flash
    vec3 lightningColor = vec3(0.7, 0.5, 1.0); // bright lavender-purple
    cloudColor += lightningColor * lightning * density * 2.5;

    return cloudColor;
}

// Main entry: raymarch through world space, returns vec4(color, opacity)
// cloudTime = integrated time for rotation, time = raw time for noise/lightning
vec4 endVoidClouds(vec3 worldDir, float cloudTime, float time, vec3 camPos, float maxDist, float suctionWarp) {
    vec3 dir = normalize(worldDir);

    float innerR = 50.0;
    float outerR = 2000.0;
    float marchEnd = min(outerR, maxDist);
    if (marchEnd <= innerR) return vec4(0.0);

    float stepSize = (outerR - innerR) / float(END_VOID_CLOUD_STEPS);

    // Screen-space dither for anti-banding — uses gl_FragCoord for smooth spatial pattern
    float dither = fract(dot(gl_FragCoord.xy, vec2(0.7548776662, 0.5698402909))) * stepSize;

    vec3 accColor = vec3(0.0);
    float accAlpha = 0.0;

    for (int i = 0; i < END_VOID_CLOUD_STEPS; i++) {
        float t = innerR + dither + float(i) * stepSize;
        if (t > marchEnd) break;

        vec3 samplePos = camPos + dir * t;

        float d = voidCloudDensity(samplePos, cloudTime, time, suctionWarp);

        if (d > 0.001) {
            float sampleAlpha = 1.0 - exp(-d * stepSize * END_VOID_CLOUD_DENSITY * 0.02);

            vec3 sampleColor = voidCloudLighting(samplePos, dir, d, t, time);

            accColor += sampleColor * sampleAlpha * (1.0 - accAlpha);
            accAlpha += sampleAlpha * (1.0 - accAlpha);

            if (accAlpha > 0.95) break;
        }
    }

    return vec4(accColor, accAlpha);
}

#endif // END_VOID_CLOUDS_ENABLED

#ifdef END_ENDER_PARTICLES_ENABLED
// Floating ender particles in world space — small glowing motes drifting in the air
// Rendered by raymarching through a repeating 3D cell grid, each cell may contain a particle
// Includes self-bloom (soft glow halo) since particles render after the bloom pipeline
vec3 endEnderParticles(vec3 viewDir, float time, vec3 camPos, float sceneDist) {
    vec3 result = vec3(0.0);
    float maxDist = min(sceneDist, END_ENDER_PARTICLE_RANGE);

    float cellSize = END_ENDER_PARTICLE_SPACING;
    float invCell = 1.0 / cellSize;
    float stepSize = cellSize * 0.7;
    float size = END_ENDER_PARTICLE_SIZE;
    float maxBloomRadius = size * 4.5; // worst-case bloom extent for early reject

    // Build screen-aligned axes once outside the loop
    vec3 right = normalize(cross(viewDir, vec3(0.0, 1.0, 0.0)));
    vec3 up = cross(right, viewDir);

    // Dither start to avoid banding
    float dither = fract(dot(gl_FragCoord.xy, vec2(0.7548776662, 0.5698402909))) * stepSize;

    vec3 lastCell = vec3(-999.0);

    for (int i = 0; i < 16; i++) {
        float t = 6.0 + dither + float(i) * stepSize; // start at near-fade distance
        if (t > maxDist) break;

        vec3 worldP = camPos + viewDir * t;
        vec3 cellId = floor(worldP * invCell);

        if (cellId == lastCell) continue;
        lastCell = cellId;

        // Random chance this cell has a particle — early reject most cells
        float rnd = endHash31(cellId + vec3(5000.0));
        if (rnd > END_ENDER_PARTICLE_DENSITY) continue;

        // Particle position within the cell
        vec3 particlePos = (cellId + vec3(
            endHash31(cellId + vec3(100.0)),
            endHash31(cellId + vec3(200.0)),
            endHash31(cellId + vec3(300.0))
        )) * cellSize;

        // Animated drift — periodic functions for seamless looping
        float phase = endHash31(cellId + vec3(400.0)) * 6.28318;
        float driftSpeed = 0.3 + endHash31(cellId + vec3(500.0)) * 0.5;
        particlePos.x += sin(time * driftSpeed * 0.4 + phase) * 0.8;
        particlePos.y += sin(time * driftSpeed * 0.3 + phase * 1.3) * 1.2
                       + sin(time * 0.05 + phase * 2.7) * cellSize * 0.4;
        particlePos.z += cos(time * driftSpeed * 0.35 + phase * 0.7) * 0.8;

        // Project particle onto view ray
        vec3 toParticle = particlePos - camPos;
        float projDist = dot(toParticle, viewDir);
        if (projDist < 6.0 || projDist > maxDist) continue;

        vec3 closest = camPos + viewDir * projDist;
        vec3 offset = particlePos - closest;

        // Chebyshev distance for square shape — early reject before expensive math
        float ox = abs(dot(offset, right));
        float oy = abs(dot(offset, up));
        float squareDist = max(ox, oy);
        if (squareDist > maxBloomRadius) continue; // outside even the bloom halo

        // Per-particle brightness variation — some glow much brighter
        float brightVar = endHash31(cellId + vec3(800.0));
        float brightMult = brightVar < 0.2 ? (2.0 + brightVar * 5.0) : (0.5 + brightVar * 0.875);

        // Hard core + soft bloom halo
        float core = step(squareDist, size);
        float bloomRadius = size * (3.0 + brightMult * 1.5);
        float bloomGlow = smoothstep(bloomRadius, size * 0.5, squareDist);
        bloomGlow *= bloomGlow;
        float totalGlow = core + bloomGlow * 0.4 * brightMult;
        if (totalGlow < 0.001) continue;

        // Pulsing brightness
        float pulse = 0.5 + 0.5 * sin(time * (1.0 + endHash31(cellId + vec3(600.0))) + phase);

        // Distance fade + near fade
        float distFade = smoothstep(maxDist, maxDist * 0.3, projDist)
                       * smoothstep(6.0, 12.0, projDist);

        // Color
        float hueRnd = endHash31(cellId + vec3(700.0));
        vec3 pColor;
        if (hueRnd < 0.4) pColor = vec3(0.6, 0.15, 1.0);
        else if (hueRnd < 0.7) pColor = vec3(0.9, 0.2, 0.8);
        else if (hueRnd < 0.85) pColor = vec3(0.3, 0.5, 1.0);
        else pColor = vec3(0.5, 0.8, 1.0);

        result += pColor * (pulse * distFade * END_ENDER_PARTICLE_BRIGHTNESS * brightMult * totalGlow);
    }

    return result;
}
#endif // END_ENDER_PARTICLES_ENABLED

#ifdef END_RINGS_ENABLED
// Torus ring — like a tire/hoop standing around the island center
// Raymarch with torus distance field for proper circular cross-section
// maxDist: scene geometry distance — ring hidden behind closer geometry
vec3 endRings(vec3 dir, float time, vec3 camPos, float maxDist) {
	dir = normalize(dir);
	vec3 baseColor = vec3(END_RINGS_R, END_RINGS_G, END_RINGS_B);
	vec3 result = vec3(0.0);

	vec3 islandCenter = vec3(0.0, 64.0, 0.0);
	float tubeR = END_RINGS_DEPTH * 0.5; // tube (cross-section) radius

	for (int i = 0; i < END_RINGS_COUNT; i++) {
		float fi = float(i);

		// Major radius — distance from island center to the ring centerline
		float majorR = END_RINGS_INNER + END_RINGS_WIDTH * 0.5 + fi * (END_RINGS_WIDTH + 20.0);

		// Orbit angle
		float orbit = time * END_RINGS_SPEED * (0.8 + fi * 0.2) + fi * 2.094;

		// Tilt oscillates: +22.5° at 0°, -22.5° at 180°
		float baseTilt = 0.3927 + fi * 0.10;
		float tilt = baseTilt * cos(orbit);

		// Ring plane normal (axis the torus wraps around)
		// Tilt from Y axis, then rotate around Y by orbit
		vec3 localN = normalize(vec3(sin(tilt), cos(tilt), 0.0));
		float cO = cos(orbit);
		float sO = sin(orbit);
		vec3 axis = vec3(
			localN.x * cO,
			localN.y,
			localN.x * sO
		);

		// Tight bounding: use two concentric spheres (inner/outer) around the torus
		// The torus lives between majorR - tubeR and majorR + tubeR from the axis
		float outerBound = majorR + tubeR * 2.0;
		vec3 toCenter = camPos - islandCenter;
		float b = dot(toCenter, dir);
		float c = dot(toCenter, toCenter) - outerBound * outerBound;
		float disc = b * b - c;
		if (disc < 0.0) continue;
		float sqrtDisc = sqrt(disc);
		float tNear = max(-b - sqrtDisc, 0.0);
		float tFar = min(-b + sqrtDisc, maxDist);
		if (tNear >= tFar) continue;

		// Raymarch — 32 steps for clean result
		float accum = 0.0;
		float stepSize = (tFar - tNear) / 32.0;
		float dither = fract(dot(gl_FragCoord.xy, vec2(0.7548776662, 0.5698402909))) * stepSize;

		for (int s = 0; s < 32; s++) {
			float t = tNear + dither + float(s) * stepSize;
			if (t > tFar) break;

			vec3 p = camPos + dir * t - islandCenter;

			// Torus SDF
			float axisProj = dot(p, axis);
			vec3 inPlane = p - axis * axisProj;
			float planeDist = length(inPlane);
			float toRing = planeDist - majorR;
			float d = length(vec2(toRing, axisProj));

			// Smooth density: 1 at center of tube, falls off to 0 at tubeR*2
			float density = smoothstep(tubeR * 2.0, 0.0, d);
			density *= density; // sharpen the core

			accum += density * stepSize;
		}

		if (accum < 0.001) continue;

		float opacity = 1.0 - exp(-accum * 0.25);

		float distFade = smoothstep(3000.0, 500.0, (tNear + tFar) * 0.5);

		vec3 thisColor = baseColor;
		if (i == 1) thisColor = mix(baseColor, vec3(0.3, 0.5, 1.0), 0.25);
		if (i == 2) thisColor = mix(baseColor, vec3(0.6, 0.2, 0.9), 0.25);

		result += thisColor * opacity * distFade * END_RINGS_BRIGHTNESS;
	}

	return result;
}
#endif

#ifdef END_VORTEX_ENABLED
// Helper: compute spiral value for a given angle (speedMult scales animation)
float endSpiralValue(float angle, float logR, float vortexTime) {
    // vortexTime is the pre-integrated animation time from the event system
    // (accounts for speed changes smoothly, no discontinuities between cycles)
    float spiralCoord = angle * END_VORTEX_ARMS + logR * END_VORTEX_TIGHTNESS * 3.0 - vortexTime * END_VORTEX_SPEED * 3.0;

    float spiral1 = sin(spiralCoord) * 0.5 + 0.5;
    spiral1 = pow(spiral1, 2.5);

    float spiral2 = sin(spiralCoord * 0.7 + 2.0) * 0.5 + 0.5;
    spiral2 = pow(spiral2, 3.0);

    float spiral3 = sin(spiralCoord * 1.3 - 1.5) * 0.5 + 0.5;
    spiral3 = pow(spiral3, 3.5);

    return spiral1 * 0.5 + spiral2 * 0.3 + spiral3 * 0.2;
}

// Void vortex — swirling light above the island
// vortexTime = pre-integrated animation time from event system (for spirals)
// time = raw time (for eye iris animation at constant speed)
// sizeMult/eyeOpen driven by the event system
vec3 endVortex(vec3 dir, float vortexTime, float time, float sizeMult, float eyeOpen) {
    if (dir.y < -0.1) return vec3(0.0);
    // During blackout (sizeMult=0), skip entirely
    if (sizeMult < 0.001 && eyeOpen < 0.001) return vec3(0.0);

    float upAmount = dir.y;
    float normDist = 1.0 - clamp(upAmount, 0.0, 1.0);
    float horizonFade = smoothstep(-0.1, 0.2, dir.y);

    // === Scale the entire vortex down with sizeMult ===
    // Divide normDist by sizeMult — everything shrinks toward center together
    float scaledDist = normDist / max(sizeMult, 0.001);

    // Two atan evaluations offset by PI to eliminate the seam
    float angle1 = atan(dir.z, dir.x);
    float angle2 = atan(-dir.z, -dir.x);

    // Spirals use original normDist for logR — decoupled from sizeMult
    // This prevents sizeMult changes from adding fake rotation (slowdown/speedup)
    // The shrinking is purely visual via scaledDist brightness below
    float logR = log(max(normDist, 0.001));

    float spirals1 = endSpiralValue(angle1, logR, vortexTime);
    float spirals2 = endSpiralValue(angle2 + 3.14159, logR, vortexTime);

    // Seam blend — smooth in BOTH x and z directions (no hard step)
    float seamBlend = smoothstep(0.5, -0.5, dir.x) * smoothstep(0.5, 0.0, abs(dir.z));
    float spirals = mix(spirals1, spirals2, seamBlend);

    // Noise modulation (uses vortexTime for smooth animation)
    float noise1 = endNoise3D(vec3(dir.xz * 4.0, vortexTime * END_VORTEX_SPEED * 0.4));
    float noise2 = endFbm3D(vec3(dir.xz * 2.0 + vortexTime * 0.05, scaledDist * 3.0), 3);
    spirals *= 0.5 + 0.5 * noise1;
    spirals *= 0.6 + 0.4 * noise2;

    // Radial brightness — uses scaled dist so it shrinks with the vortex
    float radialBright = smoothstep(1.0, 0.1, scaledDist);
    radialBright = pow(radialBright, 0.8);
    float innerBoost = smoothstep(0.5, 0.05, scaledDist) * 1.5;

    // Core glow — also scales down with everything else
    float coreGlow = smoothstep(END_VORTEX_CORE_SIZE * 2.0, 0.0, scaledDist);
    coreGlow = pow(coreGlow, 2.0);
    float hotCenter = smoothstep(END_VORTEX_CORE_SIZE * 0.8, 0.0, scaledDist);
    hotCenter = pow(hotCenter, 3.0);

    // Colors
    vec3 coreColor = vec3(END_VORTEX_R2, END_VORTEX_G2, END_VORTEX_B2);
    vec3 outerStreakColor = coreColor * 0.4;
    vec3 innerStreakColor = coreColor * 1.2;
    vec3 streakColor = mix(outerStreakColor, innerStreakColor, radialBright);

    vec3 result = vec3(0.0);
    result += streakColor * spirals * radialBright * 0.8;
    result += streakColor * spirals * innerBoost * 0.4;
    result += coreColor * coreGlow * 0.6;
    result += mix(coreColor, vec3(1.0), 0.6) * hotCenter * 0.8;

    // === Eye: rendered INSIDE the vortex core ===
    // Layout from outside-in: vortex glow → dark void ring → thin bright ring → iris tendrils → bright pupil dot
    // Eye is small — fits inside the core glow, framed by vortex light
    // Blink uses vertical eyelids (top/bottom closing), not radial expand/contract
    #ifdef END_EVENT_EYE_ENABLED
    if (eyeOpen > 0.001 && normDist < END_VORTEX_CORE_SIZE * 0.5) {
        float eyeRadius = END_VORTEX_CORE_SIZE * 0.15;
        float eyeR = normDist / eyeRadius; // 0 at center, 1 at eye edge

        // Eyelid blink — two horizontal lids that pull apart vertically
        // Proper tangent-plane vertical: dir.z / horizontal_length gives -1 to +1
        float horizLen = max(sqrt(dir.x * dir.x + dir.z * dir.z), 0.0001);
        float vertFrac = dir.z / horizLen; // -1 to +1: true vertical fraction
        float eyeY = vertFrac * eyeR; // scale by radial position in eye
        float lidHeight = eyeOpen * 1.2; // 1.2 = fully open reveals whole circle (eyeR max ~1.47)
        float eyeMask = smoothstep(lidHeight + 0.06, lidHeight - 0.06, abs(eyeY));
        eyeMask *= smoothstep(1.05, 0.90, eyeR);
        eyeMask *= smoothstep(0.0, 0.05, eyeOpen);

        if (eyeMask > 0.001) {
            vec2 eyeDir = normalize(dir.xz + 0.001);

            vec3 warmColor = vec3(END_EVENT_EYE_IRIS_R, END_EVENT_EYE_IRIS_G, END_EVENT_EYE_IRIS_B);

            // ── 1. Black out EVERYTHING in the eye area — total darkness ──
            // This covers stars, vortex glow, everything behind the eye
            result = mix(result, vec3(0.0), eyeMask);

            // ── 2. Thin bright ring at the boundary ──
            float ringR = 0.88;
            float ringDist = abs(eyeR - ringR);
            float brightRing = smoothstep(0.05, 0.005, ringDist);
            result += warmColor * 0.8 * brightRing * eyeMask;

            // ── 3. Iris tendrils — thin swirling wisps ──
            float irisInner = 0.18;
            float irisOuter = 0.72;
            float irisMask = smoothstep(irisInner - 0.03, irisInner + 0.06, eyeR)
                           * smoothstep(irisOuter + 0.05, irisOuter - 0.06, eyeR);

            // Use sin/cos of direction for continuous angular input (no atan seam)
            float tn1 = endNoise3D(vec3(eyeDir * 5.0 + eyeR * 15.0 - time * 0.3, 11.0));
            float tn2 = endNoise3D(vec3(eyeDir * 3.0 - eyeR * 10.0 + time * 0.18, 57.0));
            float tn3 = endNoise3D(vec3(eyeDir * 7.0 + eyeR * 20.0 + time * 0.1, 3.0));

            float tendrils = tn1 * 0.5 + tn2 * 0.3 + tn3 * 0.2;
            tendrils = smoothstep(0.45, 0.56, tendrils);

            float tendrilColorMix = smoothstep(0.35, 0.65, tn1);
            vec3 tendrilColor = mix(vec3(0.4, 0.25, 0.6), warmColor, tendrilColorMix);

            result += tendrilColor * tendrils * irisMask * eyeMask * 1.8;

            // Inner bright ring separating iris from pupil
            float innerRingR = irisInner + 0.02;
            float innerRingDist = abs(eyeR - innerRingR);
            float innerRing = smoothstep(0.04, 0.005, innerRingDist);
            result += warmColor * 0.5 * innerRing * eyeMask;

            // ── 4. White pupil with focus animation ──
            // Two focus constricts during the 12s eye phase, with pauses between
            // Use a 12s cycle matching the eye phase duration
            float focusCycle = mod(time, END_EVENT_CYCLE);
            float eyePhaseStart = END_EVENT_CYCLE - 22.0; // eye phase always starts 22s before cycle end
            float eyeLocalTime = focusCycle - eyePhaseStart;
            // Focus 1 at ~3s after eye opens, Focus 2 at ~8s
            float focusT = 0.0;
            // First focus: constrict at 3.0, hold small 3.3-4.5, dilate 4.5-5.5
            if (eyeLocalTime > 3.0 && eyeLocalTime < 3.3) {
                focusT = smoothstep(3.0, 3.3, eyeLocalTime); // quick constrict
            } else if (eyeLocalTime >= 3.3 && eyeLocalTime < 4.5) {
                focusT = 1.0; // hold focused (small pupil)
            } else if (eyeLocalTime >= 4.5 && eyeLocalTime < 5.5) {
                focusT = 1.0 - smoothstep(4.5, 5.5, eyeLocalTime); // slow dilate back
            }
            // Second focus: constrict at 8.0, hold small 8.25-9.2, dilate 9.2-10.0
            if (eyeLocalTime > 8.0 && eyeLocalTime < 8.25) {
                focusT = smoothstep(8.0, 8.25, eyeLocalTime);
            } else if (eyeLocalTime >= 8.25 && eyeLocalTime < 9.2) {
                focusT = 1.0; // hold focused
            } else if (eyeLocalTime >= 9.2 && eyeLocalTime < 10.0) {
                focusT = 1.0 - smoothstep(9.2, 10.0, eyeLocalTime);
            }
            float pupilSize = mix(0.14, 0.06, focusT);
            float hotSize = mix(0.05, 0.02, focusT);

            float pupilGlow = smoothstep(pupilSize, 0.0, eyeR);
            pupilGlow = pupilGlow * pupilGlow;
            result += vec3(1.0) * pupilGlow * eyeMask * 2.0;
            // Bright white core
            float hotDot = smoothstep(hotSize, 0.0, eyeR);
            result += vec3(1.0) * hotDot * eyeMask * 3.0;
        }

        // ── Bloom: soft glow that extends beyond the hard eye edges ──
        // These are wide, soft falloffs that bleed into the surrounding vortex
        vec3 bloomColor = vec3(END_EVENT_EYE_IRIS_R, END_EVENT_EYE_IRIS_G, END_EVENT_EYE_IRIS_B);
        float bloomOpen = smoothstep(0.0, 0.15, eyeOpen); // fade bloom with eye open state

        // Outer bloom — soft purple halo around the eye boundary
        float outerBloom = smoothstep(2.5, 0.8, eyeR);
        outerBloom = outerBloom * outerBloom * 0.3;
        result += bloomColor * outerBloom * bloomOpen;

        // Pupil bloom — white glow bleeding out from center
        float pupilBloom = smoothstep(0.6, 0.0, eyeR);
        pupilBloom = pupilBloom * pupilBloom * pupilBloom * 0.5;
        result += vec3(1.0) * pupilBloom * bloomOpen;

        // Iris tendril bloom — faint wide glow in the iris zone
        float irisBloom = smoothstep(1.8, 0.3, eyeR) * smoothstep(0.0, 0.15, eyeR);
        irisBloom *= 0.15;
        result += bloomColor * 0.6 * irisBloom * bloomOpen;
    }
    #endif

    result *= END_VORTEX_INTENSITY * horizonFade;

    return result;
}
#endif

// Big Bang explosion — flash + shockwave rings from zenith
// bangProgress: 0 = start of bang, 1 = end of bang
#ifdef END_EVENT_ENABLED
vec3 endBigBangRings(vec3 dir, float bangProgress, float bangFlash) {
    if (bangFlash < 0.001 && bangProgress <= 0.0) return vec3(0.0);

    vec3 result = vec3(0.0);

    // Central flash — white-purple burst at zenith, covers whole upper sky
    float upAmount = max(dir.y, 0.0);
    float flashGlow = smoothstep(0.0, 0.8, upAmount) * bangFlash;
    result += vec3(0.9, 0.7, 1.0) * flashGlow * 4.0;

    // 3 shockwave rings blasting outward from zenith — fast explosion
    if (bangProgress > 0.0 && bangProgress < 1.0) {
        float elevAngle = acos(clamp(dir.y, -1.0, 1.0));
        for (int i = 0; i < 3; i++) {
            float fi = float(i);
            float ringDelay = fi * 0.08; // tighter stagger
            float ringProgress = clamp((bangProgress - ringDelay) / max(1.0 - ringDelay, 0.01), 0.0, 1.0);
            // pow < 1 = fast start, rings shoot out quickly then slow slightly
            float ringExpand = pow(ringProgress, 0.4);
            float ringAngle = ringExpand * 3.14159; // zenith past horizon (full PI)

            float distToRing = abs(elevAngle - ringAngle);
            float ringWidth = 0.04 + fi * 0.01;
            float ring = smoothstep(ringWidth, ringWidth * 0.15, distToRing);
            float ringFade = (1.0 - ringProgress) * (1.0 - fi * 0.2);

            vec3 ringColor = mix(vec3(1.0, 0.9, 1.0), vec3(0.5, 0.3, 1.0), fi * 0.3);
            result += ringColor * ring * ringFade * 2.5;
        }
    }

    return result;
}
#endif // END_EVENT_ENABLED

vec3 renderEndSky(vec3 worldDir, float time, vec3 camPos) {
    float height = max(worldDir.y, 0.0);

    // Compute event state once for the entire pipeline
    #ifdef END_EVENT_ENABLED
    EndEvent event = getEndEvent(time);

    // Black-hole suction warp — to make stars VISUALLY move up toward zenith,
    // we warp the sample direction AWAY from zenith (toward horizon).
    // This means each pixel samples content from below, creating the visual
    // effect of everything streaming upward into the vortex.
    vec3 warpedDir = worldDir;
    if (event.suctionWarp > 0.001) {
        float warpStrength = event.suctionWarp * event.suctionWarp * 0.85;
        // Push sample direction away from zenith — toward the horizon plane
        vec3 horizonDir = normalize(vec3(worldDir.x, 0.0, worldDir.z));
        // Near-zenith pixels: push them outward so they sample from further away
        float nearZenith = clamp(worldDir.y, 0.0, 1.0);
        float pullAmount = warpStrength * nearZenith;
        warpedDir = normalize(mix(worldDir, horizonDir, pullAmount));
    }
    #else
    vec3 warpedDir = worldDir;
    #endif

    vec3 horizonColor = vec3(END_SKY_HORIZON_R, END_SKY_HORIZON_G, END_SKY_HORIZON_B);
    vec3 midColor = vec3(END_SKY_MID_R, END_SKY_MID_G, END_SKY_MID_B);
    vec3 zenithColor = vec3(END_SKY_ZENITH_R, END_SKY_ZENITH_G, END_SKY_ZENITH_B);

    vec3 sky = endBlendSkyLayers(horizonColor, midColor, zenithColor, height, 0.25, 0.65);

    if (worldDir.y < 0.0) {
        float belowFade = smoothstep(0.0, -0.4, worldDir.y);
        #ifdef END_FOG_ENABLED
        vec3 voidColor = vec3(END_FOG_R, END_FOG_G, END_FOG_B);
        #else
        vec3 voidColor = horizonColor * 0.3;
        #endif
        sky = mix(horizonColor, voidColor, belowFade);
    }

    sky *= END_SKY_BRIGHTNESS;

    // Event: darken base sky during implosion/blackout
    #ifdef END_EVENT_ENABLED
    sky *= (1.0 - event.skyDarkness);
    #endif

    #ifdef END_STARS_ENABLED
    {
        #ifdef END_EVENT_ENABLED
        vec3 stars = endStarField(warpedDir, time, event.suctionWarp);
        sky += stars * event.effectsFade;
        #else
        sky += endStarField(worldDir, time, 0.0);
        #endif
    }
    #endif
    #ifdef END_NEBULA_ENABLED
    {
        #ifdef END_EVENT_ENABLED
        sky += endNebula(warpedDir, time) * event.effectsFade;
        #else
        sky += endNebula(worldDir, time);
        #endif
    }
    #endif
    #ifdef END_AURORA_ENABLED
    {
        #ifdef END_EVENT_ENABLED
        sky += endAurora(warpedDir, time) * event.effectsFade;
        #else
        sky += endAurora(worldDir, time);
        #endif
    }
    #endif
    #ifdef END_VOID_PARTICLES_ENABLED
    {
        #ifdef END_EVENT_ENABLED
        sky += endVoidParticles(warpedDir, time, event.suctionWarp) * event.effectsFade;
        #else
        sky += endVoidParticles(worldDir, time, 0.0);
        #endif
    }
    #endif
    #ifdef END_VOID_CLOUDS_ENABLED
    {
        #ifdef END_EVENT_ENABLED
        vec4 clouds = endVoidClouds(worldDir, event.cloudTime, time, camPos, 10000.0, event.suctionWarp);
        #else
        vec4 clouds = endVoidClouds(worldDir, time, time, camPos, 10000.0, 0.0);
        #endif
        if (clouds.a > 0.001) {
            vec3 cloudRGB = clouds.rgb / clouds.a;
            #ifdef END_EVENT_ENABLED
            float cloudAlpha = clouds.a * event.effectsFade;
            #else
            float cloudAlpha = clouds.a;
            #endif
            sky = mix(sky, cloudRGB, cloudAlpha);
        }
    }
    #endif
    #ifdef END_ASTEROIDS_ENABLED
    {
        #ifdef END_EVENT_ENABLED
        sky += endWarpStreaks(warpedDir, time) * event.effectsFade;
        #else
        sky += endWarpStreaks(worldDir, time);
        #endif
    }
    #endif
    #ifdef END_VORTEX_ENABLED
    {
        #ifdef END_EVENT_ENABLED
        sky += endVortex(worldDir, event.vortexTime, time, event.vortexSizeMult, event.eyeOpen);
        #else
        sky += endVortex(worldDir, time, time, 1.0, 0.0);
        #endif
    }
    #endif

    // Big Bang flash + rings
    #ifdef END_EVENT_ENABLED
    sky += endBigBangRings(worldDir, event.bangProgress, event.bangFlash);
    #endif

    return sky;
}

#endif // END_SKY_ENABLED
