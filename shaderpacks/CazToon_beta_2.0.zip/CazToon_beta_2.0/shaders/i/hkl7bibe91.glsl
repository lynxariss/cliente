// Time-of-day and block lighting utilities

#ifndef LIGHTING_GLSL
#define LIGHTING_GLSL

#include "/include/color_utils.glsl"
#include "/include/biome_overrides.glsl"

// Minecraft-provided biome sky color (zenith). Iris/OptiFine provide this uniform.
// Declared here so all block/terrain passes that include lighting.glsl can use it.
uniform vec3 skyColor;

// Biome ID — needed for nether detection in lighting functions.
// Must be declared here (before function definitions that reference it).
uniform int biome;

// Handheld light uniforms (available in all gbuffers passes via Iris)
#ifdef HANDHELD_LIGHT_ENABLED
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform int heldItemId;
uniform int heldItemId2;
// eyePosition = player head position in world space (Iris exclusive).
// Differs from cameraPosition in third-person/detached camera situations.
uniform vec3 eyePosition;
#endif

// Forward declarations (some drivers require functions to be declared before use)
vec3 normalizeLightColor(vec3 c);
vec3 getTimeOfDaySkylightColor(float sunAngle);

// Returns an additive RGB light contribution from the held item, attenuated by distance.
// Add this directly onto color.rgb after lighting. worldPos = fragment world-space position.
#ifdef HANDHELD_LIGHT_ENABLED
vec3 getHandheldLightBoost(vec3 worldPos, vec3 baseColor, vec3 litColor) {
    float mainHeld = clamp(float(max(heldBlockLightValue,  0)) / 15.0, 0.0, 1.0);
    float offHeld  = clamp(float(max(heldBlockLightValue2, 0)) / 15.0, 0.0, 1.0);

    // Pick the brighter hand; track which item ID is dominant
    float heldLevel;
    int dominantId;
    if (mainHeld >= offHeld) {
        heldLevel   = mainHeld;
        dominantId  = heldItemId;
    } else {
        heldLevel   = offHeld;
        dominantId  = heldItemId2;
    }
    if (heldLevel < 0.001) return vec3(0.0);

    // eyePosition is the player's head in world space — unlike cameraPosition, it stays
    // on the entity in third-person/detached camera modes.
    vec3 playerCenter = eyePosition - vec3(0.0, 0.5, 0.0);
    vec3 delta = worldPos - playerCenter;

    float radius = max(HANDHELD_LIGHT_RADIUS, 0.01);

    // Use XZ distance for the main horizontal spread.
    // Clamp the vertical contribution so stepping up/down a block doesn't
    // dramatically shrink the light radius — vertical distance only starts
    // costing radius budget beyond 1 block of height difference.
    float xzDist = sqrt(delta.x * delta.x + delta.z * delta.z);
    float yOffset = max(abs(delta.y) - 1.0, 0.0); // free within 1 block vertically
    float dist = sqrt(xzDist * xzDist + yOffset * yOffset);

    // Inverse square falloff with soft knee — stays bright across most of radius,
    // drops sharply only near the edge.
    float t = clamp(dist / radius, 0.0, 1.0);
    float atten = 1.0 - t * t;
    atten = atten * atten * atten;

    float intensity = heldLevel * atten * HANDHELD_LIGHT_STRENGTH;

    // Per-item tint color:
    // Soul torch / soul lantern / soul campfire (10021, 10043) → icy blue
    // Everything else → warm torch orange
    vec3 tint;
    if (dominantId == 10021 || dominantId == 10043) {
        tint = vec3(0.3, 0.7, 1.0); // soul blue
    } else {
        tint = vec3(1.0, 0.75, 0.4); // warm torch orange
    }

    vec3 boost = baseColor * tint * intensity;

    // Scale down contribution when the surface is already well-lit so handheld
    // light only fills in dark areas instead of over-brightening lit ones.
    float existingBrightness = dot(litColor, vec3(0.299, 0.587, 0.114));
    float darkFactor = 1.0 - smoothstep(0.15, 0.7, existingBrightness);

    return boost * darkFactor;
}
#endif

vec3 applySaturationAndVibrance(vec3 c, float saturationMult, float vibrance) {
    c = max(c, vec3(0.0));

    // Saturation multiplier (simple, stable)
    float lum = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(vec3(lum), c, max(saturationMult, 0.0));

    // Vibrance: boost low-saturation colors more than already-saturated ones
    // Implemented in HSV space to avoid hue shifts.
    vec3 hsv = rgb2hsv(clamp(c, vec3(0.0), vec3(10.0)));
    float v = clamp(vibrance, 0.0, 2.0);
    hsv.y = clamp(hsv.y + (1.0 - hsv.y) * v * (1.0 - hsv.y), 0.0, 1.0);
    return hsv2rgb(hsv);
}

float getStableDayFactor(float sunAngle) {
    float angle = fract(sunAngle);
    // Stable daytime window (avoid sunrise/sunset view-dependent biome colors)
    float isDay = smoothstep(0.03, 0.10, angle) * (1.0 - smoothstep(0.40, 0.47, angle));
    return smoothstep(0.5, 0.9, isDay);
}

vec3 getBiomeSkylightColor() {
    // Normalize biome sky color so it acts as a hue tint (not a brightness dimmer).
    float biomeLum = dot(skyColor, vec3(0.299, 0.587, 0.114));
    if (biomeLum <= 0.0005) return vec3(1.0);
    return normalizeLightColor(skyColor);
}

vec3 getCombinedSkylightTintColor(float sunAngle) {
    // Combine your time-of-day skylight color with Minecraft biome sky color.
    // Biome skyColor can be view/transition sensitive; only apply it strongly during stable daytime.
    vec3 tod = getTimeOfDaySkylightColor(sunAngle);
    vec3 biome = mix(vec3(1.0), getBiomeSkylightColor(), getStableDayFactor(sunAngle));
    return normalizeLightColor(tod * biome);
}

vec4 getTimeOfDayLighting(float sunAngle) {
    float angle = fract(sunAngle);

    float dayAmount = smoothstep(0.03, 0.10, angle) * (1.0 - smoothstep(0.40, 0.47, angle));
    float sunsetAmount = smoothstep(0.38, 0.45, angle) * (1.0 - smoothstep(0.48, 0.55, angle))
                       + smoothstep(0.95, 1.0, angle) + (1.0 - smoothstep(0.0, 0.05, angle));
    float nightAmount = smoothstep(0.52, 0.58, angle) * (1.0 - smoothstep(0.92, 0.98, angle));

    float total = max(dayAmount + sunsetAmount + nightAmount, 0.25);
    dayAmount /= total;
    sunsetAmount /= total;
    nightAmount /= total;

    // Slightly less aggressive dimming at sunset so the world keeps that warm glow
    float brightness = 1.0 * dayAmount + 0.85 * sunsetAmount + 0.04 * nightAmount;

    float darkness = nightAmount + sunsetAmount * 0.4;

    // NOTE: RGB components are unused by the current lighting path; keep signature stable.
    return vec4(brightness, 0.0, 0.0, darkness);
}

vec3 normalizeLightColor(vec3 c) {
    // Keep hue while avoiding "dark" skylight colors from dimming the scene.
    float lum = dot(c, vec3(0.299, 0.587, 0.114));
    vec3 n = c / max(lum, 0.35);
    return clamp(n, vec3(0.0), vec3(2.0));
}

vec3 getTimeOfDaySkylightColor(float sunAngle) {
    float angle = fract(sunAngle);

    float isDay = smoothstep(0.03, 0.10, angle) * (1.0 - smoothstep(0.40, 0.47, angle));
    float twilight = smoothstep(0.38, 0.45, angle) * (1.0 - smoothstep(0.48, 0.55, angle))
                   + smoothstep(0.95, 1.0, angle) + (1.0 - smoothstep(0.0, 0.05, angle));
    float blueHour = smoothstep(0.50, 0.56, angle) * (1.0 - smoothstep(0.60, 0.66, angle));
    float isNight = smoothstep(0.52, 0.58, angle) * (1.0 - smoothstep(0.92, 0.98, angle));

    float total = max(isDay + twilight + blueHour + isNight, 0.25);
    isDay /= total;
    twilight /= total;
    blueHour /= total;
    isNight /= total;

    // Use your sky colors as skylight tint.
    // Bias toward horizon to get that sunset "glow" reflected onto the world.
    vec3 daySky = mix(vec3(DAY_MID_R, DAY_MID_G, DAY_MID_B), vec3(DAY_HORIZON_R, DAY_HORIZON_G, DAY_HORIZON_B), 0.35);
    vec3 sunsetSky = mix(vec3(SUNSET_MID_R, SUNSET_MID_G, SUNSET_MID_B), vec3(SUNSET_HORIZON_R, SUNSET_HORIZON_G, SUNSET_HORIZON_B), 0.75);
    vec3 blueSky = mix(vec3(BLUEHOUR_MID_R, BLUEHOUR_MID_G, BLUEHOUR_MID_B), vec3(BLUEHOUR_HORIZON_R, BLUEHOUR_HORIZON_G, BLUEHOUR_HORIZON_B), 0.70);
    vec3 nightSky = mix(vec3(NIGHT_MID_R, NIGHT_MID_G, NIGHT_MID_B), vec3(NIGHT_HORIZON_R, NIGHT_HORIZON_G, NIGHT_HORIZON_B), 0.55);

    vec3 sky = daySky * isDay + sunsetSky * twilight + blueSky * blueHour + nightSky * isNight;
    return normalizeLightColor(sky);
}

float getBlocklightFalloff(float blocklight, float skylight) {
    float x = clamp(blocklight, 0.0, 1.0);
    float falloff = x * x * x * (x * (x * 6.0 - 15.0) + 10.0);
    falloff *= smoothstep(0.0, 0.15, blocklight);
    return falloff;
}

vec3 getBlockLightColor(float intensity) {
    vec3 warmLight = vec3(1.0, 0.9, 0.8);
    return warmLight * intensity * intensity * BLOCKLIGHT_BRIGHTNESS;
}

// SIMPLE lighting for areas without shadow map
// Dark = shadow color, Lit = normal
vec3 applyLighting(vec3 color, float sunAngle, float skylight, float blocklight) {
    vec4 todLighting = getTimeOfDayLighting(sunAngle);
    float todBrightness = todLighting.x;
    float darkness = todLighting.w;

    // In the nether, skip skylight darkness attenuation entirely — the nether has
    // no sky so skylight is always 0, and the darkness slider would black out everything.
    bool isNether = isForcedNetherBiome(biome);

    float darkSteps = clamp(float(SKYLIGHT_DARKNESS_LEVELS), 0.0, 13.0);
    float darkAmt = isNether ? 0.0 : darkSteps / 13.0;
    float skyLevel = clamp(skylight * 15.0, 0.0, 15.0);
    // Z-controlled cumulative increment curve:
    // z=0.0 -> x1,x1.1,x1.2..., z=1.0 -> x1,x2,x3...
    float zBlend = clamp(SKYLIGHT_DARKNESS_Z, 0.0, 1.0);
    float a = mix(0.1, 1.0, zBlend);
    // Remap darkness levels so:
    // skylight 15 -> n=0, skylight 9 -> n=13 (14th level), skylight 1 -> n=14 (15th level).
    float n;
    if (isNether) {
        n = 0.0; // No darkness in nether
    } else if (skyLevel >= 9.0) {
        float tHigh = (15.0 - skyLevel) / 6.0;
        n = clamp(tHigh * 13.0, 0.0, 13.0);
    } else {
        float tLow = (9.0 - skyLevel) / 8.0;
        n = clamp(13.0 + tLow, 13.0, 14.0);
    }
    float cumulative = n + 0.5 * a * n * (n - 1.0);
    float total = 14.0 + 0.5 * a * 14.0 * 13.0;
    float levelWeight = cumulative / max(total, 0.0001);
    float atten = isNether ? 1.0 : (1.0 - darkAmt * levelWeight);
    // In nether: treat skylight as full (1.0) for correct ambient lighting
    float effectiveSkylight = isNether ? 1.0 : skylight;
    float lmSkylight = clamp(effectiveSkylight * atten, 0.0, 1.0);

    // Boost skylight tint at sunset/sunrise so the warm glow is stronger
    // without needing to increase the global SKYLIGHT_COLOR_TINT setting
    float angle_ = fract(sunAngle);
    float sunsetTintBoost = smoothstep(0.38, 0.45, angle_) * (1.0 - smoothstep(0.48, 0.55, angle_))
                          + smoothstep(0.95, 1.0, angle_) + (1.0 - smoothstep(0.0, 0.05, angle_));
    float tintStrength = clamp(SKYLIGHT_COLOR_TINT + sunsetTintBoost * SUNSET_TERRAIN_TINT, 0.0, 1.0);
    float lightSatBlend = clamp(SKYLIGHT_TINT_LIGHT_SATURATION, 0.0, 1.0);

    vec3 tintBase = getCombinedSkylightTintColor(sunAngle);
    // Extra saturation boost at sunset for the warm tones
    float sunsetSatBoost = 1.0 + sunsetTintBoost * (SUNSET_TERRAIN_TINT * 1.09);
    vec3 tintShadow = normalizeLightColor(applySaturationAndVibrance(tintBase, SKYLIGHT_TINT_SATURATION * sunsetSatBoost, 0.0));
    float litSat = mix(1.0, SKYLIGHT_TINT_SATURATION * sunsetSatBoost, lightSatBlend);
    vec3 tintLit = normalizeLightColor(applySaturationAndVibrance(tintBase, litSat, 0.0));

    // Shadows should only be tinted where skylight is present.
    vec3 skyTint = mix(vec3(1.0), tintShadow, tintStrength * lmSkylight);

    // Shadow color from your settings (SHADOW_HUE, SHADOW_SATURATION)
    vec3 rawShadowHue = hueToRGB(SHADOW_HUE > 0.0 ? 180.0 + SHADOW_HUE : 360.0 + SHADOW_HUE);
    float hueLuminance = dot(rawShadowHue, vec3(0.299, 0.587, 0.114));
    vec3 normalizedHue = rawShadowHue / max(hueLuminance, 0.3);
    normalizedHue = min(normalizedHue, vec3(2.0));
    // Reduce shadow saturation at night to prevent purple tint covering everything
    float nightSatReduce = smoothstep(0.0, 0.20, todBrightness); // 0 at night, 1 during day
    float effectiveLmSat = mix(LIGHTMAP_SATURATION * 0.15, LIGHTMAP_SATURATION, nightSatReduce);
    vec3 shadowTintColor = mix(vec3(1.0), normalizedHue, effectiveLmSat);

    // How much is in light vs shadow (0 = shadow, 1 = lit)
    float lightAmount = clamp(lmSkylight * todBrightness, 0.0, 1.0);
    
    // Shadow floor follows darkened skylight level directly.
    float shadowDark = 0.15 * lmSkylight;

    // Desaturate toward black as shadows get darker
    vec3 darkShadowColor = shadowTintColor * shadowDark;
    // Let the sky color leak into shadows only where skylight is actually present.
    darkShadowColor *= skyTint;

    // In light: use sky-colored skylight (strongest at sunset). In shadow: dark+tinted.
    vec3 litColor = mix(vec3(1.0), tintLit, tintStrength);
    vec3 lightMultiplier = mix(darkShadowColor, litColor, lightAmount);
    if (isNether) lightMultiplier *= NETHER_BRIGHTNESS;
    
    // Apply skylight/shadow to base color
    vec3 skylitResult = color * lightMultiplier;
    
    // Blocklight contribution (warm torch/light-block light)
    // IMPORTANT: do NOT replace skylight lighting with blocklight, otherwise the sky tint
    // disappears inside the radius gradient. Add blocklight on top instead.
    float isDaySuppress = isNether ? 0.0 : smoothstep(0.25, 0.85, todBrightness); // 0 at night, ~1 by midday
    // Only reduce blocklight based on skylight during daytime — at night the sky is open
    // but there's no sun, so blocklight should not be suppressed by sky openness.
    float effectiveBlocklight = clamp(blocklight * (1.0 - BLOCKLIGHT_SKYLIGHT_REDUCTION * lmSkylight * isDaySuppress), 0.0, 1.0);
    float blocklightFalloff = getBlocklightFalloff(effectiveBlocklight, lmSkylight);
    vec3 blockLight = getBlockLightColor(blocklightFalloff);
    float skyVis = lmSkylight;
    // Only suppress blocklight when sky is open AND it's actually daytime bright.
    // At night lmSkylight can still be ~1.0 outdoors, but isDaySuppress is ~0, so no suppression.
    float blocklightSkySuppress = 1.0 - smoothstep(0.6, 1.0, skyVis * isDaySuppress);

    #ifdef END_SHADER
    vec3 endBlockColor = vec3(END_BLOCKLIGHT_R, END_BLOCKLIGHT_G, END_BLOCKLIGHT_B);
    vec3 endBlockLight = endBlockColor * blocklightFalloff * blocklightFalloff * END_BLOCKLIGHT_BRIGHTNESS;
    vec3 result = skylitResult + color * endBlockLight;
    #else
    vec3 result = skylitResult + color * blockLight * blocklightSkySuppress;
    #endif

    // Minimum brightness for caves/night
    // Scale cave/night floor with same attenuation so level 1 can fully blacken at max slider.
    float minBright = 0.03 * (1.0 - lmSkylight + darkness * 0.5) * atten;
    result = max(result, color * shadowTintColor * minBright * skyTint);

    // Night ambient: additive brightness boost for outdoor areas at night
    if (!isNether) {
        float nightAmbientBoost = NIGHT_AMBIENT * darkness * lmSkylight;
        result += color * nightAmbientBoost;
    }

    return result;
}

// Lighting WITH shadow map data
vec3 applyLightingWithShadow(vec3 color, float sunAngle, float skylight, float blocklight, float emissive, vec3 shadow) {
    if (emissive > 0.5) {
        #ifdef END_SHADER
        // End dimension: emissive blocks glow significantly brighter to stand out against dark terrain
        return color * EMISSIVE_BRIGHTNESS * END_EMISSIVE_BOOST;
        #else
        return color * EMISSIVE_BRIGHTNESS;
        #endif
    }

    vec4 todLighting = getTimeOfDayLighting(sunAngle);
    float todBrightness = todLighting.x;
    float darkness = todLighting.w;

    // In the nether, skip skylight darkness attenuation entirely — the nether has
    // no sky so skylight is always 0, and the darkness slider would black out everything.
    bool isNether = isForcedNetherBiome(biome);

    float darkSteps = clamp(float(SKYLIGHT_DARKNESS_LEVELS), 0.0, 13.0);
    float darkAmt = isNether ? 0.0 : darkSteps / 13.0;
    float skyLevel = clamp(skylight * 15.0, 0.0, 15.0);
    // Z-controlled cumulative increment curve:
    // z=0.0 -> x1,x1.1,x1.2..., z=1.0 -> x1,x2,x3...
    float zBlend = clamp(SKYLIGHT_DARKNESS_Z, 0.0, 1.0);
    float a = mix(0.1, 1.0, zBlend);
    // Remap darkness levels so:
    // skylight 15 -> n=0, skylight 9 -> n=13 (14th level), skylight 1 -> n=14 (15th level).
    float n;
    if (isNether) {
        n = 0.0; // No darkness in nether
    } else if (skyLevel >= 9.0) {
        float tHigh = (15.0 - skyLevel) / 6.0;
        n = clamp(tHigh * 13.0, 0.0, 13.0);
    } else {
        float tLow = (9.0 - skyLevel) / 8.0;
        n = clamp(13.0 + tLow, 13.0, 14.0);
    }
    float cumulative = n + 0.5 * a * n * (n - 1.0);
    float total = 14.0 + 0.5 * a * 14.0 * 13.0;
    float levelWeight = cumulative / max(total, 0.0001);
    float atten = isNether ? 1.0 : (1.0 - darkAmt * levelWeight);
    // In nether: treat skylight as full (1.0) for correct ambient lighting
    float effectiveSkylight = isNether ? 1.0 : skylight;
    float lmSkylight = clamp(effectiveSkylight * atten, 0.0, 1.0);

    // Boost skylight tint at sunset/sunrise so the warm glow is stronger
    float angleS = fract(sunAngle);
    float sunsetTintBoostS = smoothstep(0.38, 0.45, angleS) * (1.0 - smoothstep(0.48, 0.55, angleS))
                           + smoothstep(0.95, 1.0, angleS) + (1.0 - smoothstep(0.0, 0.05, angleS));
    float tintStrength = clamp(SKYLIGHT_COLOR_TINT + sunsetTintBoostS * SUNSET_TERRAIN_TINT, 0.0, 1.0);
    float lightSatBlend = clamp(SKYLIGHT_TINT_LIGHT_SATURATION, 0.0, 1.0);

    vec3 tintBase = getCombinedSkylightTintColor(sunAngle);
    float sunsetSatBoostS = 1.0 + sunsetTintBoostS * (SUNSET_TERRAIN_TINT * 1.09);
    vec3 tintShadow = normalizeLightColor(applySaturationAndVibrance(tintBase, SKYLIGHT_TINT_SATURATION * sunsetSatBoostS, 0.0));
    float litSat = mix(1.0, SKYLIGHT_TINT_SATURATION * sunsetSatBoostS, lightSatBlend);
    vec3 tintLit = normalizeLightColor(applySaturationAndVibrance(tintBase, litSat, 0.0));

    vec3 skyTint = mix(vec3(1.0), tintShadow, tintStrength * lmSkylight);

    // Shadow color from settings
    vec3 rawShadowHue = hueToRGB(SHADOW_HUE > 0.0 ? 180.0 + SHADOW_HUE : 360.0 + SHADOW_HUE);
    float hueLuminance = dot(rawShadowHue, vec3(0.299, 0.587, 0.114));
    vec3 normalizedHue = rawShadowHue / max(hueLuminance, 0.3);
    normalizedHue = min(normalizedHue, vec3(2.0));
    // Reduce shadow saturation at night to prevent purple tint covering everything
    float nightSatReduceS = smoothstep(0.0, 0.20, todBrightness);
    float effectiveShadowSat = mix(SHADOW_SATURATION * 0.15, SHADOW_SATURATION, nightSatReduceS);
    vec3 shadowTintColor = mix(vec3(1.0), normalizedHue, effectiveShadowSat);

    // Shadow value (0 = shadowed, 1 = lit)
    float shadowVal = dot(shadow, vec3(0.299, 0.587, 0.114));

    // Let local blocklight override directional shadows near light sources.
    // This preserves torch/lantern-lit readability even when sun shadow says "dark".
    float isDaySuppress = isNether ? 0.0 : smoothstep(0.25, 0.85, todBrightness); // 0 at night, ~1 by midday
    // Only reduce blocklight based on skylight during daytime — at night the sky is open
    // but there's no sun, so blocklight should not be suppressed by sky openness.
    float effectiveBlocklight = clamp(blocklight * (1.0 - BLOCKLIGHT_SKYLIGHT_REDUCTION * lmSkylight * isDaySuppress), 0.0, 1.0);
    float blocklightFalloff = getBlocklightFalloff(effectiveBlocklight, lmSkylight);
    float shadowOverride = clamp(blocklightFalloff * BLOCKLIGHT_SHADOW_OVERRIDE, 0.0, 1.0);
    float shadowValLifted = mix(shadowVal, 1.0, shadowOverride);

    // Combine skylight and shadow
    float lightAmount = clamp(lmSkylight * todBrightness * shadowValLifted, 0.0, 1.0);

    // Shadow floor follows darkened skylight level directly.
    float shadowDark = 0.15 * lmSkylight;

    // Light multiplier: shadow color when dark, white when lit
    vec3 darkShadowColor = shadowTintColor * shadowDark;
    darkShadowColor *= skyTint;

    vec3 litColor = mix(vec3(1.0), tintLit, tintStrength);
    vec3 lightMultiplier = mix(darkShadowColor, litColor, lightAmount);

    // For colored shadows (stained glass), blend the shadow color
    vec3 coloredShadow = mix(shadow, vec3(shadowVal), 0.5);
    lightMultiplier *= mix(vec3(1.0), coloredShadow, 1.0 - shadowValLifted);
    if (isNether) lightMultiplier *= NETHER_BRIGHTNESS;

    // Skylit/shadowed result
    vec3 skylitResult = color * lightMultiplier;

    // Blocklight contribution (do not override skylight tint)
    vec3 blockLight = getBlockLightColor(blocklightFalloff);
    float skyVis = lmSkylight;
    float blocklightSkySuppress = 1.0 - smoothstep(0.6, 1.0, skyVis * isDaySuppress);

    #ifdef END_SHADER
    // End dimension: blocklight is the primary light source (no sun cycle).
    // Boost blocklight significantly so lit areas stand out from the dark ambient.
    // Never suppress blocklight in the End — there's no daytime to double-count.
    vec3 endBlockColor = vec3(END_BLOCKLIGHT_R, END_BLOCKLIGHT_G, END_BLOCKLIGHT_B);
    vec3 endBlockLight = endBlockColor * blocklightFalloff * blocklightFalloff * END_BLOCKLIGHT_BRIGHTNESS;
    vec3 result = skylitResult + color * endBlockLight;
    #else
    vec3 result = skylitResult + color * blockLight * blocklightSkySuppress;
    #endif

    // Minimum for caves
    // Scale cave/night floor with same attenuation so level 1 can fully blacken at max slider.
    float minBright = 0.03 * (1.0 - lmSkylight + darkness * 0.5) * atten;
    result = max(result, color * shadowTintColor * minBright * skyTint);

    // Night ambient: additive brightness boost for outdoor areas at night
    if (!isNether) {
        float nightAmbientBoost = NIGHT_AMBIENT * darkness * lmSkylight;
        result += color * nightAmbientBoost;
    }

    return result;
}

// Overload for float shadow (grayscale)
vec3 applyLightingWithShadow(vec3 color, float sunAngle, float skylight, float blocklight, float emissive, float shadow) {
    return applyLightingWithShadow(color, sunAngle, skylight, blocklight, emissive, vec3(shadow));
}



vec3 applyLightingEmissive(vec3 color, float sunAngle, float skylight, float blocklight, float emissive) {
    if (emissive > 0.5) {
        #ifdef END_SHADER
        return color * EMISSIVE_BRIGHTNESS * END_EMISSIVE_BOOST;
        #else
        return color * EMISSIVE_BRIGHTNESS;
        #endif
    }
    return applyLighting(color, sunAngle, skylight, blocklight);
}

vec3 applyLightingEmissiveWithWorldPos(vec3 color, float sunAngle, float skylight, float blocklight, float emissive, vec3 worldPos) {
    return applyLightingEmissive(color, sunAngle, skylight, blocklight, emissive);
}

vec3 applyTimeOfDayLighting(vec3 color, float sunAngle, float skylight) {
    return applyLighting(color, sunAngle, skylight, 0.0);
}

#endif

