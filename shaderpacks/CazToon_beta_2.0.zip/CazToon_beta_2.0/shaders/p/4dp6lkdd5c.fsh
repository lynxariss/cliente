/* RENDERTARGETS: 0,1,4 */

#include "/settings.glsl"

uniform sampler2D gtexture;

in vec2 texcoord;
in vec4 glcolor;

void main() {
	vec4 color = texture(gtexture, texcoord) * glcolor;

	gl_FragData[0] = color;
	gl_FragData[1] = vec4(0.0, 1.0, 0.0, 0.0); // G=1 = bloom, A=0 = not heat source
	gl_FragData[2] = vec4(0.0); // Clear glass tint
}
