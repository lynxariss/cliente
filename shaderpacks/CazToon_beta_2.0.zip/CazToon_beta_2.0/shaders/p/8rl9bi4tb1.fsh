/* RENDERTARGETS: 0,1,3 */

#include "/settings.glsl"
#include "/include/hovering.glsl"

uniform float far;
uniform float frameTimeCounter;
uniform int frameCounter;
uniform float sunAngle;
uniform vec3 cameraPosition;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform mat4 dhProjectionInverse;

#ifdef END_SHADER
#ifdef END_EVENT_ENABLED
#include "/include/end_event.glsl"
#endif
#endif

#include "/include/lighting.glsl"
uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
#include "/include/shadow.glsl"

// ============================================================================
// Cloud Shadow Sampling (must match gbuffers_skybasic.fsh cloud noise)
// ============================================================================
#if defined(CLOUDS_2D_ENABLED) && defined(CLOUD_SHADOWS_ENABLED)
float cloudShadowHashDH(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float cloudShadowNoiseDH(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);

    float a = cloudShadowHashDH(i);
    float b = cloudShadowHashDH(i + vec2(1.0, 0.0));
    float c = cloudShadowHashDH(i + vec2(0.0, 1.0));
    float d = cloudShadowHashDH(i + vec2(1.0, 1.0));

    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float cloudShadowFBMDH(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;

    for (int i = 0; i < 5; i++) {
        value += amplitude * cloudShadowNoiseDH(p * frequency);
        amplitude *= 0.5;
        frequency *= 2.0;
    }

    return value;
}

float getCloudShadowDH(vec3 wPos, float time) {
    // Circular wind: Clouds move in a large circle
    float r = 2500.0;
    float speed = CLOUD_SPEED * 3.0;
    float angle = time * speed / r;
    vec2 offset = vec2(cos(angle), sin(angle)) * r;

    vec2 cloudPos = (wPos.xz + offset) * CLOUD_SCALE;

    float noise = cloudShadowFBMDH(cloudPos);
    float density = smoothstep(1.0 - CLOUD_COVERAGE, 1.0 - CLOUD_COVERAGE + 0.3, noise);

    #if CLOUD_TOON_EDGES == 1
    density = step(0.3, density);
    #endif

    return 1.0 - density * CLOUD_SHADOW_STRENGTH;
}
#endif

in vec4 vColor;
in float viewDistance;
in vec3 normal;
in float NdotL;
in vec3 worldPos;
flat in int materialId;
in float skylight;
in float blockLight;
in vec4 shadowPos;

float interleaved_gradient_noise(vec2 v) {
        return fract(52.9829189 * fract(0.06711056 * v.x + 0.00583715 * v.y));
}

float hash12(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float smoothChunkNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash12(i);
    float b = hash12(i + vec2(1.0, 0.0));
    float c = hash12(i + vec2(0.0, 1.0));
    float d = hash12(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// Get emissive light color based on material type or color
vec3 getEmissiveLightColor(int matId, vec3 baseColor) {
        if (matId == DH_BLOCK_LAVA) return vec3(1.0, 0.4, 0.1);
        if (matId == DH_BLOCK_ILLUMINATED) {
                float brightness = max(max(baseColor.r, baseColor.g), baseColor.b);
                if (brightness > 0.01) {
                        return normalize(baseColor + 0.1) * 1.2;
                }
                return vec3(1.0, 0.85, 0.6);
        }
        float brightness = max(max(baseColor.r, baseColor.g), baseColor.b);
        if (brightness > 0.01) {
                return normalize(baseColor + 0.1) * 1.2;
        }
        return vec3(1.0, 0.7, 0.4);
}

// Sample shadow map
float sampleShadow(vec3 shadowCoord, float viewDistance) {
        if (shadowCoord.x < 0.001 || shadowCoord.x > 0.999 ||
            shadowCoord.y < 0.001 || shadowCoord.y > 0.999 ||
            shadowCoord.z < 0.0 || shadowCoord.z > 1.0) {
                return 1.0;
        }

    #ifdef SHARP_SHADOWS
        float mapDepth = texture(shadowtex1, shadowCoord.xy).r;
        float shadow = step(shadowCoord.z, mapDepth);
        float fadeFactor = smoothstep(SHADOW_DISTANCE * 0.9, SHADOW_DISTANCE, viewDistance);
        return mix(shadow, 1.0, fadeFactor);
    #else
        float dither = interleavedGradientNoise(gl_FragCoord.xy, frameCounter);
        float r = quartic_length(shadowCoord.xy * 2.0 - 1.0);
        float distortFactor = r + SHADOW_DISTORTION;
        return getShadowFaded(shadowtex1, shadowCoord, distortFactor, viewDistance, dither);
    #endif
}

void main() {
        vec4 color = vColor;
        vec3 originalColor = vColor.rgb;

        // Get brightness of the incoming color from DH
        float colorBrightness = max(max(originalColor.r, originalColor.g), originalColor.b);

        // Detect emissive blocks (bright colors)
        float blockLightThreshold = mix(0.9, 0.5, smoothstep(64.0, 512.0, viewDistance));
        bool isEmissive = (materialId == DH_BLOCK_ILLUMINATED) ||
                          (materialId == DH_BLOCK_LAVA) ||
                          (blockLight >= blockLightThreshold);
        float emissive = isEmissive ? 1.0 : 0.0;

        // No cave darkening for DH — all visible DH terrain is surface
        float darknessFactor = 1.0;

        // Face shading based on sun direction
        float angle = fract(sunAngle);
        float isDay = smoothstep(0.03, 0.10, angle) * smoothstep(0.47, 0.40, angle);
        float fade_start = max(far - DH_OVERDRAW_DISTANCE - DH_OVERDRAW_FADE_LENGTH, 0.0);
        float fade_end = max(far - DH_OVERDRAW_DISTANCE, 0.0);
        float overdrawFade = smoothstep(fade_start, fade_end, viewDistance);

        // In DH overdraw transition, suppress DH behind *solid* nearby vanilla geometry.
        // Require neighbor-supported depth to avoid sparse/edge pixels causing dark streak artifacts.
        if (overdrawFade > 0.001 && overdrawFade < 0.999) {
                ivec2 pixel = ivec2(gl_FragCoord.xy);
                float dC = texelFetch(depthtex0, pixel, 0).r;
                if (dC < 0.9999) {
                        float dR = texelFetch(depthtex0, pixel + ivec2(1, 0), 0).r;
                        float dL = texelFetch(depthtex0, pixel + ivec2(-1, 0), 0).r;
                        float dU = texelFetch(depthtex0, pixel + ivec2(0, -1), 0).r;
                        float dD = texelFetch(depthtex0, pixel + ivec2(0, 1), 0).r;

                        float cov = 0.0;
                        cov += step(dC, 0.9999);
                        cov += step(dR, 0.9999);
                        cov += step(dL, 0.9999);
                        cov += step(dU, 0.9999);
                        cov += step(dD, 0.9999);

                        float maxDiff = max(max(abs(dC - dR), abs(dC - dL)), max(abs(dC - dU), abs(dC - dD)));
                        bool solidCoverage = (cov >= 4.5) && (maxDiff < 0.0030);

                        if (solidCoverage) {
                                vec2 texSize = vec2(textureSize(depthtex0, 0));
                                vec2 uv = (gl_FragCoord.xy + vec2(0.5)) / texSize;

                                vec4 mcClip = vec4(uv * 2.0 - 1.0, dC * 2.0 - 1.0, 1.0);
                                vec4 mcView = gbufferProjectionInverse * mcClip;
                                float mcDist = -mcView.z / mcView.w;

                                vec4 dhClip = vec4(uv * 2.0 - 1.0, gl_FragCoord.z * 2.0 - 1.0, 1.0);
                                vec4 dhView = dhProjectionInverse * dhClip;
                                float dhDist = -dhView.z / dhView.w;

                                if (mcDist + 0.10 < dhDist) {
                                        discard;
                                }
                        }
                }
        }

        // Shadow sampling FIRST (needed for tinted lighting)
        float shadow = 1.0;
        #ifdef SHADOWS_ENABLED
        if (isDay > 0.1 && skylight > 0.05 && !isEmissive) {
                float lightDot = shadowPos.w;
                bool isSunGrazingSurface = lightDot < 0.001;

                if (isSunGrazingSurface) {
                        shadow = mix(1.0, 0.6, DH_SHADOW_OPACITY);
                } else {
                        shadow = sampleShadow(shadowPos.xyz, viewDistance);
                }

                shadow = mix(1.0, shadow, skylight);
                shadow = mix(1.0, shadow, DH_SHADOW_OPACITY);
        }
        #endif

        // Apply cloud shadows
        #if defined(CLOUDS_2D_ENABLED) && defined(CLOUD_SHADOWS_ENABLED)
        if (isDay > 0.1 && !isEmissive) {
                float cloudShadow = getCloudShadowDH(worldPos, frameTimeCounter);
                shadow *= cloudShadow;
        }
        #endif

        // In the DH overdraw transition band, fade out DH directional shadows entirely
        // to prevent double-darkening where vanilla chunk shadows are already visible,
        // and eliminate shadow sampling artifacts from distant geometry falling outside the map bounds.
        shadow = mix(shadow, 1.0, overdrawFade);

        // Sunset DH terrain darkening — at low sun angles, nearby chunks are heavily
        // self-shadowed by terrain/structures but DH has no shadows, causing a brightness mismatch.
        // Darken DH terrain proportionally to simulate the heavy shadowing at sunset/sunrise.
        float dhAngle = fract(sunAngle);
        float sunsetAmount = smoothstep(0.38, 0.45, dhAngle) * smoothstep(0.55, 0.48, dhAngle)
                           + smoothstep(0.95, 1.0, dhAngle) + smoothstep(0.05, 0.0, dhAngle);
        float dhSunsetDarken = mix(1.0, 0.65, sunsetAmount);

        // Use the exact same lighting function as loaded chunks for perfect matching
        if (!isEmissive) {
                color.rgb = applyLightingWithShadow(color.rgb, sunAngle, skylight, blockLight, 0.0, shadow);
                #ifdef HANDHELD_LIGHT_ENABLED
                color.rgb += getHandheldLightBoost(worldPos, originalColor, color.rgb);
                #endif

                color.rgb *= darknessFactor;
                color.rgb *= dhSunsetDarken;
        }

        // Apply brightness multipliers (only for non-emissive)
        // TERRAIN_BRIGHTNESS not applied — DH_BRIGHTNESS is the sole control
        if (!isEmissive) {
                color.rgb *= DH_BRIGHTNESS;
                // DH LOD contrast adjustment
                color.rgb = (color.rgb - 0.5) * DH_CONTRAST + 0.5;
                color.rgb = max(color.rgb, vec3(0.0));
                // DH color saturation
                float dhLuma = dot(color.rgb, vec3(0.299, 0.587, 0.114));
                color.rgb = mix(vec3(dhLuma), color.rgb, DH_SATURATION);

                // End dimension: terrain patches + darken terrain + bluish-purple ambient tint
                #ifdef END_SHADER
                {
                    // Random darkness patches on ground surfaces for visual variety
                    #ifdef END_TERRAIN_PATCHES_ENABLED
                    {
                        float patchUpFacing = max(normal.y, 0.0);
                        if (patchUpFacing > 0.3) {
                            vec2 patchPos = worldPos.xz * END_TERRAIN_PATCH_SCALE;
                            float pn = 0.0;
                            float pAmp = 0.6;
                            for (int octave = 0; octave < 3; octave++) {
                                vec2 ip = floor(patchPos);
                                vec2 fp = fract(patchPos);
                                fp = fp * fp * (3.0 - 2.0 * fp);
                                float a = fract(sin(dot(ip, vec2(127.1, 311.7))) * 43758.5453);
                                float b = fract(sin(dot(ip + vec2(1.0, 0.0), vec2(127.1, 311.7))) * 43758.5453);
                                float c = fract(sin(dot(ip + vec2(0.0, 1.0), vec2(127.1, 311.7))) * 43758.5453);
                                float d = fract(sin(dot(ip + vec2(1.0, 1.0), vec2(127.1, 311.7))) * 43758.5453);
                                pn += mix(mix(a, b, fp.x), mix(c, d, fp.x), fp.y) * pAmp;
                                patchPos *= 2.3;
                                pAmp *= 0.45;
                            }
                            float patchDark = smoothstep(0.25, 0.55, pn);
                            patchDark = mix(1.0, 1.0 - END_TERRAIN_PATCH_STRENGTH, 1.0 - patchDark);
                            color.rgb *= mix(1.0, patchDark, patchUpFacing);
                        }
                    }
                    #endif

                    float dhBaseDarken = 0.55;
                    float dhTintMult = 0.15;
                    float dhColorShift = 0.55;

                    // Blocklight + handheld to preserve through event darkness
                    float dhPreserveBlend = 0.0;
                    vec3 dhPreservedLight = vec3(0.0);

                    #if defined(END_SHADER) && defined(END_EVENT_ENABLED)
                    float dhEventDarkness = getEndEventTerrainDarkness(frameTimeCounter);
                    if (dhEventDarkness > 0.001) {
                        // Recompute blocklight contribution (mirrors lighting.glsl END_SHADER path)
                        float bFalloff = getBlocklightFalloff(blockLight, skylight);
                        vec3 endBlockColor = vec3(END_BLOCKLIGHT_R, END_BLOCKLIGHT_G, END_BLOCKLIGHT_B);
                        dhPreservedLight = originalColor * endBlockColor * bFalloff * bFalloff * END_BLOCKLIGHT_BRIGHTNESS * TERRAIN_BRIGHTNESS * DH_BRIGHTNESS;

                        #ifdef HANDHELD_LIGHT_ENABLED
                        dhPreservedLight += getHandheldLightBoost(worldPos, originalColor, vec3(0.0)) * TERRAIN_BRIGHTNESS * DH_BRIGHTNESS;
                        #endif

                        dhPreserveBlend = dhEventDarkness;
                    }
                    dhBaseDarken = mix(dhBaseDarken, 0.02, dhEventDarkness);
                    dhTintMult = mix(dhTintMult, 0.0, dhEventDarkness);
                    dhColorShift = mix(dhColorShift, 0.0, dhEventDarkness);
                    #endif

                    color.rgb *= dhBaseDarken;
                    vec3 purpleTint = vec3(0.08, 0.06, 0.35);
                    color.rgb += purpleTint * dhTintMult;
                    color.rgb = mix(color.rgb, color.rgb * vec3(0.55, 0.58, 1.35), dhColorShift);

                    // Restore blocklight + handheld through darkness
                    color.rgb += dhPreservedLight * dhPreserveBlend;
                }
                #endif
        }

        // Emissive blocks: blend between white and original color based on settings
        if (isEmissive) {
                vec3 whiteGlow = vec3(1.0);
                vec3 coloredGlow = originalColor;
                vec3 emissiveColor = mix(whiteGlow, coloredGlow, DH_EMISSIVE_COLOR_STRENGTH);
                float cappedBrightness = min(EMISSIVE_BRIGHTNESS * DH_BRIGHTNESS, DH_EMISSIVE_BRIGHTNESS_CAP);
                #ifdef END_SHADER
                cappedBrightness *= END_EMISSIVE_BOOST;
                #endif
                color.rgb = emissiveColor * cappedBrightness;
        }

        #ifdef DH_EMISSIVE_DEBUG
        if (isEmissive) {
                color.rgb = vec3(1.0);
        }
        #endif

        float dither = interleaved_gradient_noise(gl_FragCoord.xy + float(frameCounter));
        /* Replace dither fade out overdraw with Y-axis sink wipe */
        if (overdrawFade < 0.999) {
            float reveal = overdrawFade; // Near=0 (hidden), Far=1 (revealed)
            float minY = SEA_LEVEL_OFFSET - 96.0;
            float maxY = SEA_LEVEL_OFFSET + 320.0;
            // Add World position jitter so edge isn't perfectly flat
            float mask = smoothChunkNoise(worldPos.xz * 0.12);
            float jitterY = (mask - 0.5) * 10.0;
            float revealY = mix(minY, maxY, reveal) + jitterY;
            float visible = 1.0 - smoothstep(revealY - 8.0, revealY + 8.0, worldPos.y);
            color.rgb *= mix(0.60, 1.0, visible);
            if (visible < 0.02 || (dither > overdrawFade && overdrawFade < 0.05)) { // Combine standard dither just for the absolute deepest cuts to soften the lowest threshold
                discard;
            }
        }

        gl_FragData[0] = color;
        gl_FragData[1] = vec4(1.0, emissive * DH_EMISSIVE_INTENSITY, skylight, 0.0);
        vec3 lightColor = vec3(0.0);
        if (isEmissive) {
                lightColor = getEmissiveLightColor(materialId, vColor.rgb) * DH_EMISSIVE_INTENSITY;
                #ifdef END_SHADER
                lightColor *= END_EMISSIVE_BOOST;
                #endif
        }
        gl_FragData[2] = vec4(lightColor, 1.0);
}
