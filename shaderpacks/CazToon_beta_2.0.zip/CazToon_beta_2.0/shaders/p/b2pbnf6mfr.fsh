/* RENDERTARGETS: 0,1,3,4,5 */

#include "/settings.glsl"
#include "/include/shadow.glsl"
#include "/include/lighting.glsl"

uniform sampler2D gtexture;
uniform sampler2D shadowtex0;
uniform float alphaTestRef;
uniform float sunAngle;
uniform int currentRenderedItemId;
uniform vec3 shadowLightPosition;
uniform int frameCounter;

#ifdef END_SHADER
uniform float frameTimeCounter;
#ifdef END_EVENT_ENABLED
#include "/include/end_event.glsl"
#endif
#endif

in vec2 texcoord;
in vec4 glcolor;
in float skylight;
in float blocklight;
in float viewDistance;
in vec4 shadowPos;
in vec3 normal;
in vec3 worldPos;

void main() {
	vec4 color = texture(gtexture, texcoord) * glcolor;

	// Texture palette limiting
	#ifdef TEXTURE_PALETTE_ENABLED
	{
		float levels = float(TEXTURE_PALETTE_LEVELS);
		color.rgb = floor(color.rgb * levels) / levels;
	}
	#endif

	if (color.a < alphaTestRef) {
		discard;
	}

	vec3 rawColor = color.rgb;

	// Detect emissive held items (torch, lantern, glowstone, end rod, etc.)
	bool isEmissiveItem = (currentRenderedItemId == 10020 ||  // torch, lantern, campfire, candles
	                       currentRenderedItemId == 10021 ||  // soul torch, soul lantern
	                       currentRenderedItemId == 10022 ||  // lava bucket, fire charge
	                       currentRenderedItemId == 10023 ||  // glowstone, glow lichen
	                       currentRenderedItemId == 10024 ||  // sea lantern, beacon
	                       currentRenderedItemId == 10025 ||  // shroomlight
	                       currentRenderedItemId == 10026 ||  // redstone torch/lamp
	                       currentRenderedItemId == 10027 ||  // ochre froglight
	                       currentRenderedItemId == 10028 ||  // verdant froglight
	                       currentRenderedItemId == 10029 ||  // pearlescent froglight
	                       currentRenderedItemId == 10031 ||  // end rod
	                       currentRenderedItemId == 10043);   // soul variants (LPV)

	#ifdef END_SHADER
	if (isEmissiveItem) {
		color.rgb = rawColor * EMISSIVE_BRIGHTNESS * END_EMISSIVE_BOOST;
	} else {
		// Non-emissive hand: apply lighting with shadow, then End darkening
		#ifdef SHADOWS_ENABLED
		if (shadowPos.w > 0.5) {
			float dotNL = dot(normal, normalize(shadowLightPosition));
			float dither = interleavedGradientNoise(gl_FragCoord.xy, frameCounter);
			float r = quartic_length(shadowPos.xy * 2.0 - 1.0);
			float distortFactor = r + SHADOW_DISTORTION;

			float selfShadowBias = 0.003;
			float slopeBias = (SHADOW_NORMAL_BIAS * 0.0001) * (1.1 - dotNL);
			float totalBias = selfShadowBias + slopeBias;

			vec3 biasedShadowPos = shadowPos.xyz;
			biasedShadowPos.z -= totalBias;

			vec3 shadow = getShadowColorPCF(shadowtex0, shadowcolor0, biasedShadowPos, distortFactor, dither, 0.0);

			float fadeFactor = smoothstep(SHADOW_DISTANCE * 0.8, SHADOW_DISTANCE, viewDistance);
			shadow = mix(shadow, vec3(1.0), fadeFactor);
			float shadowSkylight = max(skylight, 0.15);
			shadow = mix(vec3(1.0), shadow, shadowSkylight);
			shadow = mix(vec3(1.0), shadow, SHADOW_OPACITY);

			float handShadowVal = dot(shadow, vec3(0.299, 0.587, 0.114));
			float handSkylight = max(skylight, handShadowVal * 0.95);
			color.rgb = applyLightingWithShadow(color.rgb, sunAngle, handSkylight, blocklight, 0.0, shadow);
		} else {
			color.rgb = applyLighting(color.rgb, sunAngle, skylight, blocklight);
		}
		#else
		color.rgb = applyLighting(color.rgb, sunAngle, skylight, blocklight);
		#endif

		// Apply End dimension darkening (matches terrain baseDarken)
		float baseDarken = 0.55;
		float tintMult = 0.15;

		// Blocklight to preserve through event darkness
		float preserveBlend = 0.0;
		vec3 preservedLight = vec3(0.0);

		#if defined(END_SHADER) && defined(END_EVENT_ENABLED)
		float eventDarkness = getEndEventTerrainDarkness(frameTimeCounter);
		if (eventDarkness > 0.001) {
			float bFalloff = getBlocklightFalloff(blocklight, skylight);
			vec3 endBlockColor = vec3(END_BLOCKLIGHT_R, END_BLOCKLIGHT_G, END_BLOCKLIGHT_B);
			preservedLight = rawColor * endBlockColor * bFalloff * bFalloff * END_BLOCKLIGHT_BRIGHTNESS;
			preserveBlend = eventDarkness;
		}
		baseDarken = mix(baseDarken, 0.02, eventDarkness);
		tintMult = mix(tintMult, 0.0, eventDarkness);
		#endif

		color.rgb *= baseDarken;
		vec3 purpleTint = vec3(0.08, 0.06, 0.35);
		color.rgb += purpleTint * tintMult;

		// Restore blocklight through darkness
		color.rgb += preservedLight * preserveBlend;

		// Apply handheld light to the player's own hand (End)
		#ifdef HANDHELD_LIGHT_ENABLED
		color.rgb += getHandheldLightBoost(worldPos, rawColor, color.rgb);
		#endif
	}
	#else
	// Overworld / Nether
	if (isEmissiveItem) {
		color.rgb = rawColor * EMISSIVE_BRIGHTNESS;
	} else {
		#ifdef SHADOWS_ENABLED
		if (shadowPos.w > 0.5) {
			float dotNL = dot(normal, normalize(shadowLightPosition));
			float dither = interleavedGradientNoise(gl_FragCoord.xy, frameCounter);
			float r = quartic_length(shadowPos.xy * 2.0 - 1.0);
			float distortFactor = r + SHADOW_DISTORTION;

			float selfShadowBias = 0.003;
			float slopeBias = (SHADOW_NORMAL_BIAS * 0.0001) * (1.1 - dotNL);
			float totalBias = selfShadowBias + slopeBias;

			vec3 biasedShadowPos = shadowPos.xyz;
			biasedShadowPos.z -= totalBias;

			vec3 shadow = getShadowColorPCF(shadowtex0, shadowcolor0, biasedShadowPos, distortFactor, dither, 0.0);

			float fadeFactor = smoothstep(SHADOW_DISTANCE * 0.8, SHADOW_DISTANCE, viewDistance);
			shadow = mix(shadow, vec3(1.0), fadeFactor);
			float shadowSkylight = max(skylight, 0.15);
			shadow = mix(vec3(1.0), shadow, shadowSkylight);
			shadow = mix(vec3(1.0), shadow, SHADOW_OPACITY);

			float handShadowVal = dot(shadow, vec3(0.299, 0.587, 0.114));
			float handSkylight = max(skylight, handShadowVal * 0.95);
			color.rgb = applyLightingWithShadow(color.rgb, sunAngle, handSkylight, blocklight, 0.0, shadow);
		} else {
			color.rgb = applyLighting(color.rgb, sunAngle, skylight, blocklight);
		}
		#else
		color.rgb = applyLighting(color.rgb, sunAngle, skylight, blocklight);
		#endif

		// Apply handheld light to the player's own hand
		#ifdef HANDHELD_LIGHT_ENABLED
		color.rgb += getHandheldLightBoost(worldPos, rawColor, color.rgb);
		#endif
	}
	#endif

    float emissiveStrength = isEmissiveItem ? 1.0 : 0.0;
	gl_FragData[0] = color;
	// alpha 0.5 designates entity in the composite pass, suppressing background bloom bleed
	gl_FragData[1] = vec4(0.0, emissiveStrength, 0.0, 0.5);
	
	vec3 bloomColor = vec3(0.0);
	if (isEmissiveItem) {
	    // Emit pure bright color into the bloom buffer matching the visual strength
	    bloomColor = rawColor * EMISSIVE_BRIGHTNESS;
	    #ifdef END_SHADER
	    bloomColor *= END_EMISSIVE_BOOST;
	    #endif
	}
	
	gl_FragData[2] = vec4(bloomColor, 1.0);
	gl_FragData[3] = vec4(0.0);
	gl_FragData[4] = vec4(0.0);
}
