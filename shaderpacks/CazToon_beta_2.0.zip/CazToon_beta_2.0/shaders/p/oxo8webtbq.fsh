/* RENDERTARGETS: 0,1,4 */

// Particles shader - handles flames, smoke, sparks, etc.

#include "/settings.glsl"
#include "/include/biome_overrides.glsl"

uniform sampler2D gtexture;
uniform float alphaTestRef;
uniform int biome;
uniform vec3 cameraPosition;

in vec2 texcoord;
in vec4 glcolor;
in vec3 worldPos;

float hash12_particle(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float smoothChunkNoiseParticle(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash12_particle(i);
    float b = hash12_particle(i + vec2(1.0, 0.0));
    float c = hash12_particle(i + vec2(0.0, 1.0));
    float d = hash12_particle(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

void main() {
    vec4 color = texture(gtexture, texcoord) * glcolor;

    // Texture palette limiting
    #ifdef TEXTURE_PALETTE_ENABLED
    {
        float levels = float(TEXTURE_PALETTE_LEVELS);
        color.rgb = floor(color.rgb * levels) / levels;
    }
    #endif

    if (color.a < alphaTestRef) {
        discard;
    }

    #if defined(CHUNK_FADE_OUT_ENABLED)
    if (!isForcedNetherBiome(biome) && !isForcedEndBiome(biome)) {
        float horizontalDist = length(worldPos.xz - cameraPosition.xz);
        float distGate = smoothstep(CHUNK_FADE_OUT_RADIUS, CHUNK_FADE_OUT_RADIUS + 24.0, horizontalDist);
        if (distGate > 0.001) {
            float reveal = 1.0 - distGate; // Near=1, Far=0
            float minY = SEA_LEVEL_OFFSET - 96.0;
            float maxY = SEA_LEVEL_OFFSET + 320.0;
            float mask = smoothChunkNoiseParticle(worldPos.xz * 0.12);
            float jitterY = (mask - 0.5) * 10.0;
            float revealY = mix(minY, maxY, reveal) + jitterY;
            float visible = 1.0 - smoothstep(revealY - 8.0, revealY + 8.0, worldPos.y);
            color.a *= visible;
            if (color.a < alphaTestRef) discard;
        }
    }
    #endif

    // Detect emissive particles based on final color brightness and warmth
    float brightness = dot(color.rgb, vec3(0.299, 0.587, 0.114));
    float warmth = color.r - color.b; // Fire/flame particles are warm (more red than blue)

    // Detect smoke/campfire clouds (gray, low saturation)
    float maxC = max(max(color.r, color.g), color.b);
    float minC = min(min(color.r, color.g), color.b);
    float saturation = (maxC > 0.001) ? (maxC - minC) / maxC : 0.0;
    bool isSmoke = saturation < 0.15 && brightness > 0.3 && brightness < 0.95; // Gray particles = smoke

    // Detect block breaking particles (moderate brightness, moderate saturation, not warm)
    bool isBlockBreaking = brightness < 0.85 && warmth < 0.3 && saturation < 0.7;

    // Emissive if bright OR warm (catches flames, lava, glow particles)
    // Uses configurable thresholds
    // Excludes smoke/campfire clouds and block breaking particles
    float emissive = 0.0;
    if (!isSmoke && !isBlockBreaking && (brightness > PARTICLE_BLOOM_THRESHOLD || (warmth > PARTICLE_BLOOM_WARMTH && brightness > PARTICLE_BLOOM_THRESHOLD * 0.5))) {
        emissive = PARTICLE_BLOOM_INTENSITY; // Use particle-specific bloom strength
        color.rgb *= EMISSIVE_BRIGHTNESS;
    }

    gl_FragData[0] = color;
    // R = outline mask (0 = no outline for particles), G = emissive for bloom, B = particle marker, A = not heat source
    gl_FragData[1] = vec4(0.0, emissive, 1.0, 0.0); // B=1.0 marks this as a particle
    
    // Clear glass tint so particles are detected as entities, not glass
    gl_FragData[2] = vec4(0.0);
}
