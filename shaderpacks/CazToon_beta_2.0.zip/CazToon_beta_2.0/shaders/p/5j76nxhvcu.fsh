/* RENDERTARGETS: 0,1,3,4,5 */

#include "/settings.glsl"

uniform sampler2D gtexture;
uniform float alphaTestRef;
uniform float frameTimeCounter;

in vec2 texcoord;
in vec4 glcolor;
in vec3 worldPos;
in vec3 normal;
in float isHologram;

float random(float x) {
	return fract(sin(x * 12.9898) * 43758.5453);
}

void main() {
	vec4 color = texture(gtexture, texcoord) * glcolor;

	// Texture palette limiting
	#ifdef TEXTURE_PALETTE_ENABLED
	{
		float levels = float(TEXTURE_PALETTE_LEVELS);
		color.rgb = floor(color.rgb * levels) / levels;
	}
	#endif

	if (color.a < alphaTestRef) {
		discard;
	}

	float emissive = 0.0;

	gl_FragData[0] = color;
	gl_FragData[1] = vec4(1.0, emissive, 0.0, 0.0);
	gl_FragData[2] = vec4(0.0);
	gl_FragData[3] = vec4(0.0);
	gl_FragData[4] = vec4(0.0);
}
