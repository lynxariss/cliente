
#include "/settings.glsl"
#include "/include/hovering.glsl"

const float ambientOcclusionLevel = 0.0;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;

out vec4 vColor;
out float viewDistance;
out vec3 viewDir;
out vec3 viewPos;
out vec3 worldPos;
out vec3 normal;
flat out int materialId;

void main() {
	vColor = gl_Color;

	vec3 vPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
	vec3 scenePos = (gbufferModelViewInverse * vec4(vPos, 1.0)).xyz;
	vec3 world_pos = scenePos + cameraPosition;
	bool isWater = (dhMaterialId == DH_BLOCK_WATER);
	
	// Apply hovering zone offset
	float hoverOffset = getHoverOffset(world_pos);
	world_pos.y += hoverOffset;
	scenePos = world_pos - cameraPosition;
	vPos = (gbufferModelView * vec4(scenePos, 1.0)).xyz;
	gl_Position = gl_ProjectionMatrix * vec4(vPos, 1.0);

	viewDistance = length(vPos);
	viewDir = normalize(scenePos);
	viewPos = vPos;
	worldPos = world_pos;

	// Base geometric normal (DH water is rendered as flat geometry; waves are applied in fragment).
	normal = normalize(gl_NormalMatrix * gl_Normal);

	// DH material ID (built-in from Iris)
	materialId = dhMaterialId;
}
