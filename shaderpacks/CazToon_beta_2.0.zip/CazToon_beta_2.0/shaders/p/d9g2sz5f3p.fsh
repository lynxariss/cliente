/* RENDERTARGETS: 0,1,2 */

#include "/settings.glsl"
#include "/include/biome_overrides.glsl"

uniform sampler2D gtexture;
uniform vec3 shadowLightPosition; // Use shadow light position (respects sunPathRotation)
uniform vec3 sunPosition; // Keep for fallback
uniform vec3 fogColor;
uniform vec3 skyColor;
uniform int biome;
uniform int biome_category;

in vec2 uv;
in vec3 viewPos;
in vec4 tint;

bool isSkylessWorldHeuristic() {
    float sunLen = length(sunPosition);
    float shadowLen = length(shadowLightPosition);
    vec3 skyMax = max(skyColor, vec3(0.0));
    vec3 fogMax = max(fogColor, vec3(0.0));
    float skyPeak = max(max(skyMax.r, skyMax.g), skyMax.b);
    float fogPeak = max(max(fogMax.r, fogMax.g), fogMax.b);
    bool noDirectionalLight = (sunLen < 0.001 && shadowLen < 0.001);
    bool darkFlatAtmosphere = (skyPeak < 0.06 && fogPeak < 0.08);
    return darkFlatAtmosphere && noDirectionalLight;
}

void main() {
    // Skyless/server custom dimensions: don't render sky-textured quads
    // (sun/moon/stars texture pass), otherwise they appear as bright squares.
    if (isSkylessWorldHeuristic()) {
        discard;
    }

    // End: no sun or moon in the void
    #ifdef END_SKY_ENABLED
    {
        bool endLike = false;
        #ifdef CAT_THE_END
        endLike = (biome_category == CAT_THE_END);
        #else
        endLike = isForcedEndBiome(biome);
        #endif
        if (endLike) discard;
    }
    #endif

    vec4 color = texture(gtexture, uv) * tint;

    if (color.a < 0.1) discard;
    
    // Detect sun/moon vs stars
    // Use shadowLightPosition which respects sunPathRotation setting
    float sunDot = dot(normalize(viewPos), normalize(shadowLightPosition));
    float moonDot = dot(normalize(viewPos), normalize(-shadowLightPosition));
    bool isSunMoon = sunDot > 0.8 || moonDot > 0.8;
    
    #ifdef STARS_ENABLED
    // If procedural stars are enabled, remove likely vanilla star pixels.
    // Keep a robust fail-safe so sun/moon are not accidentally discarded.
    if (!isSunMoon) {
        float lum = dot(color.rgb, vec3(0.299, 0.587, 0.114));
        bool likelyStar = (lum < 0.20) && (color.a < 0.99);
        if (likelyStar) discard;
    }
    #endif
    
    gl_FragData[0] = color;
    
    // Mark sun/moon as emissive (always, so they render on top of fog)
    float emissive = isSunMoon ? 1.0 : 0.0;
    gl_FragData[1] = vec4(0.0, emissive, 0.0, 0.0);
    
    // Output bloom color for sun/moon — sunset-only gating done in final.fsh
    vec3 sunBloom = color.rgb * SUN_MOON_BLOOM;
    gl_FragData[2] = vec4(sunBloom, 1.0);
}
