
#include "/settings.glsl"
#include "/include/shadow.glsl"

uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;
uniform int entityId;
uniform float frameTimeCounter;
// Iris: block.properties ID of the item currently being rendered (per draw call)
uniform int currentRenderedItemId;

out vec2 texcoord;
out vec4 glcolor;
out float viewDistance;
out float skylight;
out float blocklight;
out float emissive;
flat out float emissiveType;
out vec4 shadowPos;
out vec3 normal;
out vec3 worldPos;
out float nametagHolo;

void main() {
        gl_Position = ftransform();
        texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

        // Vanilla applies per-vertex diffuse shading to entities, which can look "too dark".
        // However, fully removing it makes entities look overly bright/flat in sunlight.
        // Use ENTITY_BRIGHTNESS_BOOST as a blend factor:
        //   0.0 = keep vanilla shading
        //   1.0 = fully flatten (normalize brightness)
        float vertexBrightness = max(gl_Color.r, max(gl_Color.g, gl_Color.b));
        vec3 vanilla = gl_Color.rgb;
        vec3 flatColor = (vertexBrightness > 0.01) ? (gl_Color.rgb / vertexBrightness) : gl_Color.rgb;
        glcolor.rgb = mix(vanilla, flatColor, clamp(ENTITY_BRIGHTNESS_BOOST, 0.0, 1.0));
        glcolor.a = gl_Color.a;

        vec3 viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
        viewDistance = length(viewPos);
        skylight = clamp(gl_MultiTexCoord1.y / 240.0, 0.0, 1.0);
        blocklight = clamp(gl_MultiTexCoord1.x / 240.0, 0.0, 1.0);

        // GeckoLib emissive layer compiles this pass with EMISSIVE defined.
        // Keep normal entities non-emissive, but mark the glowmask pass as emissive.
        #ifdef EMISSIVE
        emissive = 1.0;
        emissiveType = 0.0;
        #else
        emissive = 0.0;
        emissiveType = 0.0;

        // Detect held emissive items (torch, lantern, etc.) via Iris currentRenderedItemId
        // This uniform gives the block.properties ID of the item being rendered
        int itemBlockId = max(currentRenderedItemId - 10000, 0);
        if ((itemBlockId >= 20 && itemBlockId <= 63) || itemBlockId == 6) {
                emissive = 1.0;
                emissiveType = float(itemBlockId == 6 ? 0 : itemBlockId - 20);
        }
        #endif

        // Shadow position for cast shadows
        shadowPos = vec4(0.0);
        #ifdef SHADOWS_ENABLED
        // Normal in view space
        normal = normalize(gl_NormalMatrix * gl_Normal);

        vec3 scenePos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
        vec4 shadowClipPos4 = shadowProjection * shadowModelView * vec4(scenePos, 1.0);
        vec3 shadowClipPosXYZ = shadowClipPos4.xyz;
        float bias = computeBias(shadowClipPosXYZ);
        vec3 distorted = distortShadowClipPos(shadowClipPosXYZ);
        shadowPos.xyz = distorted * 0.5 + 0.5;
        // Normal bias
        vec4 shadowNormal = shadowProjection * vec4(mat3(shadowModelView) * (mat3(gbufferModelViewInverse) * (gl_NormalMatrix * gl_Normal)), 1.0);
        shadowPos.xyz += shadowNormal.xyz / shadowNormal.w * bias;
        shadowPos.w = 1.0; // Mark as valid
        #else
        vec3 scenePos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
        #endif

        worldPos = scenePos + cameraPosition;

        nametagHolo = 0.0;
}
