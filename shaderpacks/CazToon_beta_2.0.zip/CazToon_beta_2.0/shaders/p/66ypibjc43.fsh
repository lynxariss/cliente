/* RENDERTARGETS: 0,8 */
// Composite 8 ? 3D Volumetric Cloud rendering
// Moved here from final.fsh so TAA (composite9) can smooth the clouds

#include "/settings.glsl"
#include "/include/biome_overrides.glsl"

#ifdef CLOUDS_3D_ENABLED
#include "/include/volumetric_clouds.glsl"
#endif

#ifdef CLOUDS_VANILLA_ENABLED
#include "/include/vanilla_clouds.glsl"
#endif

uniform sampler2D colortex0; // Scene color
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform sampler2D dhDepthTex; // DH depth ? used to skip cloud rendering where DH terrain exists

uniform float near;
uniform float far;
uniform float dhNearPlane;
uniform float dhFarPlane;
uniform float sunAngle;
uniform int worldDay;
uniform int worldTime;
uniform int frameCounter;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 shadowLightPosition;
uniform vec3 fogColor;
uniform vec3 skyColor;
uniform int biome;
uniform int biome_category;
uniform float rainStrength;
uniform float thunderStrength;

in vec2 texcoord;

// Linearize DH depth to view-space distance
float linearizeDepthDH(float depth) {
    return (dhNearPlane * dhFarPlane) / (depth * (dhNearPlane - dhFarPlane) + dhFarPlane);
}

bool hasValidDHDepth(float depth) {
    return depth > 0.00001 && depth < 0.9999;
}

// Reconstruct world Y from DH depth (same method as final.fsh getWorldPosDH)
float getDhWorldY(vec2 uv, float depth) {
    float linearDepth = linearizeDepthDH(depth);
    vec4 clipPos = vec4(uv * 2.0 - 1.0, -1.0, 1.0);
    vec4 viewPosNear = gbufferProjectionInverse * clipPos;
    viewPosNear /= viewPosNear.w;
    vec3 viewDir = normalize(viewPosNear.xyz);
    vec3 viewPos = viewDir * (linearDepth / max(abs(viewDir.z), 0.001));
    vec4 worldPos = gbufferModelViewInverse * vec4(viewPos, 1.0);
    return worldPos.y + cameraPosition.y;
}

// End dimension detection (simplified from final.fsh)
bool isEnd() {
    #ifdef END_SHADER
    return true;
    #else
    #ifdef CAT_THE_END
    return biome_category == CAT_THE_END;
    #else
    return isForcedEndBiome(biome);
    #endif
    #endif
}

void main() {
    vec3 color = texture(colortex0, texcoord).rgb;
    float cloudAlpha = 0.0; // Track cloud coverage for final.fsh
    float cloudDepthOut = 0.0;

    // DH depth handling: use DH terrain distance to cap cloud raymarching
    // This allows clouds to render ABOVE distant DH ground (clouds are closer
    // to camera along the ray than the ground), while DH structures that are
    // closer than the clouds will naturally occlude them via maxDist capping.
    float dhDepth = texture(dhDepthTex, texcoord).r;
    bool hasDhAtPixel = hasValidDHDepth(dhDepth);
    float depth0 = texture(depthtex0, texcoord).r;
    float depth1 = texture(depthtex1, texcoord).r;
    bool isSky = (depth0 >= 1.0);

    // Compute view direction and maxDist once for all cloud types
    vec3 cloudDir;
    float cloudMaxDistVanilla;
    float cloudMaxDist3D;

    if (!isSky) {
        // MC geometry present ? cap ray at MC terrain distance
        vec4 clipPos = vec4(texcoord * 2.0 - 1.0, depth1 * 2.0 - 1.0, 1.0);
        vec4 viewPos = gbufferProjectionInverse * clipPos;
        viewPos /= viewPos.w;
        vec3 worldPos = (gbufferModelViewInverse * viewPos).xyz + cameraPosition;
        cloudDir = normalize(worldPos - cameraPosition);
        float sceneDist = length(worldPos - cameraPosition);
        cloudMaxDistVanilla = sceneDist;
        cloudMaxDist3D = sceneDist;
    } else {
        // Sky pixel ? get view direction
        cloudDir = normalize(mat3(gbufferModelViewInverse) * (gbufferProjectionInverse * vec4(texcoord * 2.0 - 1.0, 1.0, 1.0)).xyz);
        cloudMaxDistVanilla = 30000.0;
        cloudMaxDist3D = 30000.0;

        // Cap both vanilla and volumetric clouds by DH depth on sky pixels so
        // DH terrain/LODs can occlude clouds correctly.
        if (hasDhAtPixel) {
            float dhLinear = linearizeDepthDH(dhDepth);
            // Convert linear view-Z depth to distance along this pixel's ray.
            vec4 clipFar = vec4(texcoord * 2.0 - 1.0, 1.0, 1.0);
            vec4 viewPosFar = gbufferProjectionInverse * clipFar;
            vec3 viewDir = normalize(viewPosFar.xyz / max(viewPosFar.w, 0.0001));
            float dhRayDist = dhLinear / max(-viewDir.z, 0.001);
            float cappedDist = max(dhRayDist - 1.0, 0.0);
            cloudMaxDistVanilla = min(cloudMaxDistVanilla, cappedDist);
            cloudMaxDist3D = min(cloudMaxDist3D, cappedDist);
        }
    }

    // Built-in biome atmosphere tint for clouds.
    // Uses biome sky color ? no fog dependency.
    // Tint is luminance-matched to each cloud pixel so shadow undersides get a dark
    // version of the biome hue and lit tops get a bright version, instead of
    // everything being pulled toward a single flat mid-range color.
    vec3 biomeAtmColor = getForcedBiomeSkyColorCat(biome, biome_category, skyColor);
    float biomeAtmLum = max(dot(biomeAtmColor, vec3(0.299, 0.587, 0.114)), 0.001);

    // Active during day and sunset, off at night.
    float btAngle = fract(sunAngle);
    float biomeTintAmount = smoothstep(0.0, 0.07, btAngle) * smoothstep(0.57, 0.48, btAngle) * 0.75;

    // Clouds fade out as rain starts ? weather fog replaces them visually.
    // Starts fading at 0.15 (before fog is dense), fully gone by 0.70
    // so there's clean overlap-free handoff: clouds out ? fog visible.
    float cloudRainFade = 1.0 - smoothstep(0.15, 0.70, rainStrength);

    #ifdef CLOUDS_VANILLA_ENABLED
    if (!isEnd() && !isForcedNetherBiome(biome)) {
        vec3 vanSunDir = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
        float vanTimeSec = (float(worldDay) * 24000.0 + float(worldTime)) / 20.0;

        float vanHitT = 0.0;
        vec4 vanResult = renderVanillaClouds(cloudDir, vanTimeSec, cameraPosition, sunAngle, vanSunDir, cloudMaxDistVanilla, gl_FragCoord.xy, frameCounter, vanHitT);
        vanResult.a *= cloudRainFade;
        if (vanResult.a > 0.001) {
            // Scale biome color to the cloud pixel's own brightness so every region gets tinted
            float cLum = max(dot(vanResult.rgb, vec3(0.299, 0.587, 0.114)), 0.001);
            vec3 biomeMatch = clamp(biomeAtmColor * (cLum / biomeAtmLum), vec3(0.0), vec3(2.0));
            vanResult.rgb = mix(vanResult.rgb, biomeMatch, biomeTintAmount);
            color = color * (1.0 - vanResult.a) + vanResult.rgb;
            cloudAlpha = max(cloudAlpha, vanResult.a);
            cloudDepthOut = vanHitT;
        }
    }
    #endif

    #ifdef CLOUDS_3D_ENABLED
    if (!isEnd() && !isForcedNetherBiome(biome)) {
        vec3 vc3dSunDir = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
        float gameTimeSec = (float(worldDay) * 24000.0 + float(worldTime)) / 20.0;

        vec4 vc3dResult = renderVolumetricClouds(cloudDir, gameTimeSec, cameraPosition, sunAngle, vc3dSunDir, cloudMaxDist3D, gl_FragCoord.xy, frameCounter);
        vc3dResult.a *= cloudRainFade;

        if (vc3dResult.a > 0.001) {
            float cLum = max(dot(vc3dResult.rgb, vec3(0.299, 0.587, 0.114)), 0.001);
            vec3 biomeMatch = clamp(biomeAtmColor * (cLum / biomeAtmLum), vec3(0.0), vec3(2.0));
            vc3dResult.rgb = mix(vc3dResult.rgb, biomeMatch, biomeTintAmount);
            color = color * (1.0 - vc3dResult.a) + vc3dResult.rgb;
            cloudAlpha = max(cloudAlpha, vc3dResult.a);
        }
    }
    #endif

    // Store cloud alpha so final.fsh can protect cloud pixels from fog/fake terrain
    gl_FragData[0] = vec4(color, 1.0 - cloudAlpha);
    gl_FragData[1] = vec4(cloudDepthOut, 0.0, 0.0, 1.0);
}

